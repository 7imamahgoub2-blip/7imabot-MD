let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
*↷─────〔 🌳 〕─────↶*
*مـࢪحـبـاََ مـطـوري ❤️ ¦ ${taguser} ¦ 💖*
*شـوف هـذه هـيـه الاوامـر الـي تـحـتاجـها 💝*
*↷─────〔 🌳 〕─────↶*

∘₊✧──────🌹──────✧₊∘
> ✘ صلح
> ✘ باتش(كل الانواع)
> ✘ بان
> ✘ الغاء_البان
> ✘ انضم
> ✘ ادخل
> ✘ اخرج
> ✘ ضـيـف
> ✘ امـسح
> ✘ زيـل
> ✘ 1كـشـف
> ✘ أفـحـص 
> ✘ سـكـربـت 
∘₊✧──────🌹──────✧₊∘

قَـسٰــــم࣬ يــقَــډم࣬ أوامر المطور فقط 💖👨‍💻
`;

  const emojiReaction = '♣️';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(
      m.chat,
      {
        image: { url: 'https://files.catbox.moe/3i6ryn.jpg' },
        caption: message,
        mentions: [m.sender]
      }
    );
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق10)$/i;
handler.exp = 50;
handler.fail = null;
handler.owner = true;  // ✅ تمت إضافة الخاصية

export default handler;