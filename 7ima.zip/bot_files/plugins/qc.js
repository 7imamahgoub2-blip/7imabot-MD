import { sticker } from '../lib/sticker.js';
import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix, command }) => {
    let text;

    // استخراج النص
    if (args.length >= 1) {
        text = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return conn.reply(m.chat, '⚠️ | *انت ناسي تكتب النص يا باشا!*', m);
    }

    if (!text) return conn.reply(m.chat, '⚠️ | *انت ناسي تكتب النص يا ملك!*', m);

    // تحديد الشخص اللي نعمل له الاقتباس
    const who = m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0]
        : m.fromMe ? conn.user.jid : m.sender;

    // منع تكرار ال@ داخل النص
    const mentionRegex = new RegExp(`@${who.split('@')[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*`, 'g');
    const texto = text.replace(mentionRegex, '');

    // الحد الأقصى للنص
    if (texto.length > 40) 
        return conn.reply(m.chat, '🚫 | *النص لازم يكون أقل من 40 حرف يا وحش!*', m);

    // صورة واسم الشخص
    const pp = await conn.profilePictureUrl(who).catch(() => 'https://telegra.ph/file/24fa902ead26340f3df2c.png');
    const nombre = await conn.getName(who);

    // جسم الـ API
    const obj = {
        type: "quote",
        format: "png",
        backgroundColor: "#000000",
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            entities: [],
            avatar: true,
            from: { id: 1, name: nombre, photo: { url: pp } },
            text: texto,
            replyMessage: {}
        }]
    };

    try {
        // إرسال الطلب
        const res = await axios.post('https://bot.lyo.su/quote/generate', obj, {
            headers: { 'Content-Type': 'application/json' }
        });

        // تحويله لصورة + استيكر
        const buffer = Buffer.from(res.data.result.image, 'base64');
        const stiker = await sticker(
            buffer,
            false,
            global.packname || 'حقوق',
            global.author || 'The shadow'
        );

        if (stiker) {
            await conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m });
        } else {
            return conn.reply(m.chat, '❌ | *ماقدرتش أعمل الاستيكر للأسف!*', m);
        }

    } catch (e) {
        console.error(e);
        return conn.reply(m.chat, `❌ | *حصل خطأ:* ${e.message}`, m);
    }
};

handler.help = ['ح'];
handler.tags = ['sticker'];
handler.command = ['qc', 'حق']; // الأوامر الجديدة

export default handler;