import db from '../lib/database.js';
import { createHash } from 'crypto';
import fetch from 'node-fetch';

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i;
let handler = async function (m, { conn, text, usedPrefix, command }) {
  let user = global.db.data.users[m.sender];
  let name2 = conn.getName(m.sender);

  if (user.registered === true) {
    return m.reply(`*😈 يا ${name2}, أنت مسجل بالفعل بصفتك أحد الوصايا العشر!*`);
  }

  if (!Reg.test(text)) {
    return m.reply(
      `*😈 أدخل اسمك وعمرك بأسلوب نجم!*\n\n*مثال:* .تسجيل 𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜. 20`
    );
  }

  let [_, name, splitter, age] = text.match(Reg);
  if (!name) return conn.reply(m.chat, '*😈 الاسم لا يمكن أن يكون فارغًا مثل بشري بدون قوي سحريه!*', m);
  if (!age) return conn.reply(m.chat, '*😈 العمر مطلوب لي الانضمام لي الوصايا العشر!*', m);

  age = parseInt(age);

  if (age < 15) return m.reply('*⚡عضو صغير لا يوجيد القتال تدرب قليلا*');
  if (age >= 51 && age <= 85) return m.reply('*😈 لا نأخذ اعضاء الوصايا متقاعدين! خذ سيفك وارجع تقاعدك!*');
   if (age >= 86 && age <= 100) return m.reply('*😔 هذا البوت لي محاربين الوصايا العشر، مش لحفلات الشاي يا حج.*');
  if (age > 100) return m.reply('*😕 لا يمكن تسجيل عضو وصايا من عصر الاول!*');

  user.name = name.trim();
  user.age = age;
  user.regTime = +new Date();
  user.registered = true;

  let sn = createHash('md5').update(m.sender).digest('hex').slice(0, 6);

  let imgUrl = [
    'https://files.catbox.moe/j8z3ea.jpg',
    'https://files.catbox.moe/14ou0j.jpg',
    'https://files.catbox.moe/picdr6.jpg'
  ].getRandom();

  let imgBuffer;
  try {
    imgBuffer = await (await fetch(imgUrl)).buffer();
  } catch (error) {
    console.error('[ERROR] لم يتمكن من تحميل الصورة:', error);
    return m.reply('[❌] لم يتم تحميل صورة احد الوصايا العشر. حاول لاحقا.');
  }

  let now = new Date();
  let date = now.toLocaleDateString('ar-AR', { year: 'numeric', month: 'long', day: 'numeric' });

  let txt = `╭══•ೋ✧﷽✧ೋ•══╮
*『الــتــســجــــيــل❄』*
╰══•ೋ✧❄✧ೋ•══╯
*☯️ الاسم:* 『 ${name} 』
*⛩️ العمر:* 『 ${age} سنة 』
*⚡ تاريخ التسجيل:* ${date}
*🌀 الرقم التسلسلي:* #${sn}
⎔⋅• ━ ╼╃⎔╷ﷺ╵⎔╄╾ ━ •⋅⎔
*مرحبًا بك بين صفوف الوصايا العشر😈*`;

  let dev = '『 😈 𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝 😈 』';

  await conn.sendMessage(m.chat, {
    image: imgBuffer,
    caption: txt,
    footer: dev,
    buttons: [
      {
        buttonId: `.بروفايل`,
        buttonText: { displayText: '⚔️ الملف الشخصي' },
      },
      {
        buttonId: `.اوامر`,
        buttonText: { displayText: '☁️ القائمة الرئيسية' },
      },
    ],
    viewOnce: true,
    headerType: 4,
  }, { quoted: m });

  await m.react('🫡');
};

handler.help = ['تسجيل'].map(v => v + ' *<الاسم.العمر>*');
handler.tags = ['start'];
handler.command = ['verify', 'reg', 'register', 'تسجيل'];

export default handler;