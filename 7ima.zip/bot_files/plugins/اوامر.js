function clockString(ms) {

    let h = Math.floor(ms / 3600000);

    let m = Math.floor((ms % 3600000) / 60000);

    let s = Math.floor((ms % 60000) / 1000);

    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');

}

import pkg from '@whiskeysockets/baileys';

const { generateWAMessageFromContent, prepareWAMessageMedia } = pkg;

const handler = async (m, { conn }) => {

    try {

        let d = new Date(Date.now() + 3600000);

        let locale = 'ar';

        let uptime = clockString(process.uptime() * 1000);

        let user = global.db.data.users[m.sender] || {};

        let name = conn.getName(m.sender);

        let { role, level } = user;

        let mentionId = m.key.participant || m.key.remoteJid;

        let taguser = '@' + m.sender.split("@s.whatsapp.net")[0];

        await conn.sendMessage(m.chat, { react: { text: '🍷', key: m.key } });

        const Elsony = 'https://files.catbox.moe/picdr6.jpg';

        const media = await prepareWAMessageMedia({ image: { url: Elsony } }, { upload: conn.waUploadToServer });

        let message = {

            viewOnceMessage: {

                message: {

                    interactiveMessage: {

                        header: { title: "gataVidMenu" },

                        body: { text: `*⌬═━━━═⊰⬩﷽⬩⊱═━━━═⌬*

*┃السلام عليكم ورحمه الله وبركاته 🩸*

*⌬═━━━━═⊰⬩🍷⬩⊱═━━━━═⌬*  

*┃ اهلا بك في بوت مليودس*

┃ ⌜ @${mentionId.split('@')[0]} ⌟  

*⌬═━═⊰⬩معلومات البوت⬩⊱═━═⌬*

*❦║اســــــم الــــبــــوت↫『 𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝 🤖』*

*❦║الــــمــــطــــور↫『 Barhoum 👑』*

*❦║رقــــم الــــمــــطــــور↫『 wa.me/201067668406 📞』*  

*⌬═━═⊰⬩مــعــلــومــاتــك⬩⊱═━═⌬* 

*❦║مــســتــواك↫『 ${level}  🆙』*

*❦║فــلــوســك↫『 ${user.money || 0} 🪙 』*  

*⌬═━━━━═⊰⬩🍷⬩⊱═━━━━═⌬*

┃ *اضغط على الأزرار لعرض القائمة 🎴*  

┃ *الرجاء عدم سب البوت لكي لا يتم حظرك! ❌*  

*⌬══⊰⬩𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝⬩⊱══⌬* `, subtitle: "Elsony" },

                        header: { hasMediaAttachment: true, ...media },

                        contextInfo: { mentionedJid: [m.sender], isForwarded: false },

                        nativeFlowMessage: {

                            buttons: [

                                {

                                    name: 'single_select',

                                    buttonParamsJson: JSON.stringify({

                                        title: '⌈🍷║اوامر البوت║🍷⌋',

                                        sections: [

                                            {

                                                title: '❪🤖┊قسم الأوامر┊🤖❫',

                                                highlight_label: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝',

                                                rows: [

                                                    { header: '👑║الـقـسـم الأول', title: '🍷║「قـسـم_الـجـروبـات」👑', id: '.ق1' },

                                                    { header: '🐦‍🔥║القـ🐦‍🔥ـسـم الثاني', title: '🍷║「قـسـم_الـمـشـرفـيـن」🌋', id: '.ق2' },

                                                    { header: '🛠️║القـ🛠️ـسـم الثالث', title: '🍷║「قـسـم_الادوات」🌋', id: '.ق3' },

                                                    { header: '⏳║القـ⏳ـسـم الرابع', title: '🍷║「قـسـم_الـتـحـمـيـل」🌋', id: '.ق4' },

                                                    { header: '🏦║القـ🏦ـسـم الخامس', title: '🍷║「قـسـم_الـبـنـك」🌋', id: '.ق5' },

                                                    { header: '🤖║القـ🤖ـسـم السادس', title: '🍷║「قـسـم_الــAI」🌋', id: '.ق6' },

                                                          { header: '⚽║القـ⚽ـسـم السابع', title: '🍷║「قـسـم_الانـذارات_الالـقـاب」🌋', id: '.ق7' },

                                                    { header: '📜║القـ📜ـسـم الثامن', title: '🍷║「 قـسـم_الـقـوانـيـن 」🌋', id: '.ق8' }

                                                ]

                                            }

                                        ]

                                    })

                                },

                                {

                                    name: "cta_url",

                                    buttonParamsJson: '{"display_text":"⌈📩║جروب الدعم║📩⌋","url":"https://chat.whatsapp.com/JMrIfSKC8W24q96FOM8F0A"}'

                                },

                                {

                                    name: "cta_url",

                                    buttonParamsJson: '{"display_text":"⌈📲║قـنـاة الـمـطـور║📲⌋","url":"https://whatsapp.com/channel/0029VbB5KQM2ZjCkwJZrOS2e"}'

                                },

                                {

                                    name: "quick_reply",

                                    buttonParamsJson: '{"display_text":"⌈🚀║المطور║🚀⌋","id":".المطور"}'

                                }

                            ]

                        }

                    }

                }

            }

        };

        await conn.relayMessage(m.chat, message, {});

    } catch (err) {

        console.error(err);

        await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m });

    }

};

handler.help = ['info'];

handler.tags = ['main'];

handler.command = ['menu', 'الاوامر', 'اوامر', 'الأوامر', 'أوامر', 'امر'];

export default handler;