import fetch from "node-fetch"

import yts from "yt-search"

import Jimp from "jimp"

import axios from "axios"

import crypto from "crypto"

import fs from "fs"

import { spawn } from "child_process"

import { promisify } from "util"

import { fileURLToPath } from "url"

import path, { dirname } from "path"

const __filename = fileURLToPath(import.meta.url)

const __dirname = dirname(__filename)

const MAX_FILE_SIZE = 500 * 1024 * 1024 // 500 MB

const AUDIO_DOC_THRESHOLD = 30 * 1024 * 1024 // 30 MB

// Función para convertir MP3 a WhatsApp Audio válido

function convertToWhatsAppAudio(inputPath, outputPath) {

    return new Promise((resolve, reject) => {

        // FFmpeg parameters optimized for WhatsApp voice notes

        const ffmpeg = spawn('ffmpeg', [

            '-i', inputPath,

            '-c:a', 'libopus',

            '-b:a', '64k',

            '-ac', '1',

            '-ar', '16000',

            '-vbr', 'on',

            '-compression_level', '10',

            '-frame_duration', '60',

            '-application', 'voip',

            outputPath

        ])

        ffmpeg.stderr.on('data', (data) => {

            console.log('FFmpeg:', data.toString())

        })

        ffmpeg.on('close', (code) => {

            if (code === 0) {

                resolve(true)

            } else {

                reject(new Error(`FFmpeg failed with code ${code}`))

            }

        })

        ffmpeg.on('error', (err) => {

            reject(err)

        })

    })

}

async function resizeImage(buffer, size = 300) {

    try {

        const image = await Jimp.read(buffer)

        return await image.resize(size, size).getBufferAsync(Jimp.MIME_JPEG)

    } catch {

        return buffer

    }

}

// API SaveTube

const savetube = {

    api: {

        base: "https://media.savetube.me/api",

        info: "/v2/info",

        download: "/download",

        cdn: "/random-cdn"

    },

    headers: {

        accept: "*/*",

        "content-type": "application/json",

        origin: "https://yt.savetube.me",

        referer: "https://yt.savetube.me/",

        "user-agent": "Postify/1.0.0"

    },

    crypto: {

        hexToBuffer: (hexString) => {

            const matches = hexString.match(/.{1,2}/g)

            return Buffer.from(matches.join(""), "hex")

        },

        decrypt: async (enc) => {

            const secretKey = "C5D58EF67A7584E4A29F6C35BBC4EB12"

            const data = Buffer.from(enc, "base64")

            const iv = data.slice(0, 16)

            const content = data.slice(16)

            const key = savetube.crypto.hexToBuffer(secretKey)

            const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv)

            let decrypted = decipher.update(content)

            decrypted = Buffer.concat([decrypted, decipher.final()])

            return JSON.parse(decrypted.toString())

        }

    },

    isUrl: (str) => {

        try {

            new URL(str)

            return /youtube.com|youtu.be/.test(str)

        } catch {

            return false

        }

    },

    youtube: (url) => {

        const patterns = [

            /youtube.com\/watch\?v=([a-zA-Z0-9_-]{11})/,

            /youtube.com\/embed\/([a-zA-Z0-9_-]{11})/,

            /youtu.be\/([a-zA-Z0-9_-]{11})/

        ]

        for (let pattern of patterns) {

            const match = url.match(pattern)

            if (match) return match[1]

        }

        return null

    },

    request: async (endpoint, data = {}, method = "post") => {

        try {

            const { data: response } = await axios({

                method,

                url: `${endpoint.startsWith("http") ? "" : savetube.api.base}${endpoint}`,

                data: method === "post" ? data : undefined,

                params: method === "get" ? data : undefined,

                headers: savetube.headers

            })

            return { status: true, code: 200, data: response }

        } catch (error) {

            return { status: false, code: error.response?.status || 500, error: error.message }

        }

    },

    getCDN: async () => {

        const response = await savetube.request(savetube.api.cdn, {}, "get")

        if (!response.status) return response

        return { status: true, code: 200, data: response.data.cdn }

    },

    download: async (link, type = "audio") => {

        if (!savetube.isUrl(link)) return { status: false, code: 400, error: "URL inválida" }

        const id = savetube.youtube(link)

        if (!id) return { status: false, code: 400, error: "No se pudo obtener el ID del video" }

        try {

            const cdnx = await savetube.getCDN()

            if (!cdnx.status) return cdnx

            const cdn = cdnx.data

            const videoInfo = await savetube.request(`https://${cdn}${savetube.api.info}`, { url: `https://www.youtube.com/watch?v=${id}` })

            if (!videoInfo.status || !videoInfo.data?.data) return { status: false, code: 500, error: "No se pudo obtener información del video" }

            const decrypted = await savetube.crypto.decrypt(videoInfo.data.data)

            const downloadData = await savetube.request(

                `https://${cdn}${savetube.api.download}`,

                { id, downloadType: type === "audio" ? "audio" : "video", quality: type === "audio" ? "mp3" : "720p", key: decrypted.key }

            )

            if (!downloadData?.data?.data?.downloadUrl) return { status: false, code: 500, error: "No se pudo obtener link de descarga" }

            return {

                status: true,

                code: 200,

                result: {

                    title: decrypted.title || "Desconocido",

                    author: decrypted.channel || "Desconocido",

                    views: decrypted.viewCount || "Desconocido",

                    timestamp: decrypted.lengthSeconds || "0",

                    ago: decrypted.uploadedAt || "Desconocido",

                    format: type === "audio" ? "mp3" : "mp4",

                    download: downloadData.data.data.downloadUrl,

                    thumbnail: decrypted.thumbnail || null

                }

            }

        } catch (error) {

            return { status: false, code: 500, error: error.message }

        }

    }

}

async function downloadWithFallback(url, type = 'audio') {

    return await savetube.download(url, type)

}

function formatSize(bytes) {

    if (!bytes || isNaN(bytes)) return 'Desconocido'

    const units = ['B', 'KB', 'MB', 'GB']

    let i = 0

    bytes = Number(bytes)

    while (bytes >= 1024 && i < units.length - 1) {

        bytes /= 1024

        i++

    }

    return `${bytes.toFixed(2)} ${units[i]}`

}

async function getSize(url) {

    try {

        const res = await axios.head(url, {

            timeout: 10000,

            headers: { 'User-Agent': 'Mozilla/5.0' }

        })

        return parseInt(res.headers['content-length'], 10) || 0

    } catch {

        return 0

    }

}

const handler = async (m, { conn, text, usedPrefix, command }) => {

    // Si es comando de descarga directa

    if (['ytmp3', 'ytmp4', 'ytmp3doc', 'ytmp4doc'].includes(command)) {

        return await handleDownload(m, conn, text, command, usedPrefix)

    }

    // Comando play principal

    if (!text?.trim()) {

        return conn.reply(m.chat, `❗ أدخل اسم الصوت أو فيديو.

📝 مثال: ${usedPrefix + command} الشيخ المنشاوي`, m)

    }

    await m.react('🔍')

    try {

        const search = await yts(text)

        const videoInfo = search.all?.[0]

        if (!videoInfo) {

            throw '❗ لم يتم العثور على نتائج.'

        }

        const { title, thumbnail, timestamp, views, ago, url, author } = videoInfo

        const vistas = views?.toLocaleString?.() || 'Desconocido'

        const cleanTitle = title.substring(0, 100)

        const cleanAuthor = author.name.substring(0, 50)

        const body = `╭━━━━━━━━━━━━━╮

│ ⚠️ تحذير: المطور غير مسؤول عن اي محتوى غير اخلاقي و يحملك المسؤوليه كامله و اعلم ان الله يراك

╰━━━━━━━━━━━━━╯

📹 ${cleanTitle}

👤 قناة: ${cleanAuthor}

👁️ مشاهدات: ${vistas}

⏱️ مدة: ${timestamp}

📅 تاريخ النشر: ${ago}

🔗 الرابط: ${url}

> اختر أحد الخيارات:`

        const buttons = [

            { buttonId: `${usedPrefix}ytmp3 ${url}`, buttonText: { displayText: '🎧 صوت' } },

            { buttonId: `${usedPrefix}ytmp4 ${url}`, buttonText: { displayText: '📽️ فيديو' } },

            { buttonId: `${usedPrefix}ytmp3doc ${url}`, buttonText: { displayText: '💿 مستند صوت' } },

            { buttonId: `${usedPrefix}ytmp4doc ${url}`, buttonText: { displayText: '🎥 مستند فيديو' } }

        ]

        try {

            // Método 1: sendMessage con botones

            await conn.sendMessage(m.chat, {

                image: { url: thumbnail },

                caption: body,

                footer: `𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝`,

                buttons: buttons,

                viewOnce: true,

                headerType: 4

            }, { quoted: m })

        } catch (e1) {

            try {

                // Método 2: sendButton

                await conn.sendButton(m.chat, body, `𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝`, thumbnail, buttons, m)

            } catch (e2) {

                try {

                    // Método 3: sendFile con caption

                    await conn.sendFile(m.chat, thumbnail, 'thumbnail.jpg', body + `\n\n*Comandos disponibles:*\n• ${usedPrefix}ytmp3 ${url}\n• ${usedPrefix}ytmp4 ${url}\n• ${usedPrefix}ytmp3doc ${url}\n• ${usedPrefix}ytmp4doc ${url}`, m)

                } catch (e3) {

                    // Método 4: Mensaje de texto simple

                    await conn.reply(m.chat, body + `\n\n*Usa estos comandos:*\n• ${usedPrefix}ytmp3 ${url}\n• ${usedPrefix}ytmp4 ${url}\n• ${usedPrefix}ytmp3doc ${url}\n• ${usedPrefix}ytmp4doc ${url}`, m)

                }

            }

        }

        await m.react('✅')

    } catch (e) {

        await m.react('❌')

        return conn.reply(m.chat, typeof e === 'string' ? e : `⚠️ خطأ: ${e.message}`, m)

    }

}

async function handleDownload(m, conn, text, command, usedPrefix) {

    if (!text?.trim()) {

        return conn.reply(m.chat, `❌ أدخل رابطًا أو اسمًا.

📝 مثال: ${usedPrefix + command} الشيخ المنشاوي`, m)

    }

    await m.react('⏳')

    try {

        let url, title, thumbnail, author

        // Si es URL directa

        if (/youtube.com|youtu.be/.test(text)) {

            const id = text.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1]

            if (!id) throw '❌ URL inválida'

            const search = await yts({ videoId: id })

            url = `https://www.youtube.com/watch?v=${id}`

            title = search.title || "Sin título"

            thumbnail = search.thumbnail

            author = search.author?.name || "Desconocido"

        } else {

            // Si es búsqueda

            const search = await yts(text)

            if (!search.videos.length) throw "❌ لم يتم العثور على نتائج"

            const videoInfo = search.videos[0]

            url = videoInfo.url

            title = videoInfo.title

            thumbnail = videoInfo.thumbnail

            author = videoInfo.author?.name || "Desconocido"

        }

        console.log(`🎯 Descargando: ${title}`)

        const thumbResized = await resizeImage(await (await fetch(thumbnail)).buffer(), 300)

        // YTMP3 - Audio (como nota de voz)

        if (command === 'ytmp3') {

            await conn.reply(m.chat, `╭━━━━━━━━━━━━━╮

│ ⏳ *جاري التحميل...*

╰━━━━━━━━━━━━━╯

🎵 *${title}*

⚡ _جارٍ معالجة الصوت..._

🎬 _قد يستغرق بضع دقائق..._

`, m)

            const dl = await downloadWithFallback(url, 'audio')

            if (!dl.status) throw dl.error || '❌ Error al descargar'

            const size = await getSize(dl.result.download)

            console.log(`📦 Tamaño: ${formatSize(size)}`)

            const fkontak = {

                key: { fromMe: false, participant: "0@s.whatsapp.net" },

                message: {

                    documentMessage: {

                        title: `🎵「 ${title} 」⚡`,

                        fileName: `𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝`,

                        jpegThumbnail: thumbResized

                    }

                }

            }

            if (size > AUDIO_DOC_THRESHOLD) {

                await conn.sendMessage(m.chat, {

                    document: { url: dl.result.download },

                    mimetype: 'audio/mpeg',

                    fileName: `${title}.mp3`,

                    caption: `🎵 *${title}*\n📦 ${formatSize(size)}\n👤 ${author}`,

                    jpegThumbnail: thumbResized

                }, { quoted: fkontak })

            } else {

                // CREAR ARCHIVOS TEMPORALES

                const tempDir = path.join(__dirname, 'temp')

                if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

                const timestamp = Date.now()

                const tempInput = path.join(tempDir, `input_${timestamp}.mp3`)

                const tempOutput = path.join(tempDir, `output_${timestamp}.opus`)

                try {

                    // 1. Descargar el audio

                    const audioResponse = await fetch(dl.result.download)

                    const buffer = await audioResponse.arrayBuffer()

                    fs.writeFileSync(tempInput, Buffer.from(buffer))

                    // 2. Convertir a formato WhatsApp compatible

                    await convertToWhatsAppAudio(tempInput, tempOutput)

                    // 3. Leer el audio convertido

                    const audioBuffer = fs.readFileSync(tempOutput)

                    // 4. Enviar como audio WhatsApp válido

                    await conn.sendMessage(m.chat, {

                        audio: audioBuffer,

                        mimetype: 'audio/ogg; codecs=opus',

                        ptt: true,

                        fileName: `${title}.ogg`

                    }, { quoted: fkontak })

                    // 5. Limpiar archivos temporales

                    if (fs.existsSync(tempInput)) fs.unlinkSync(tempInput)

                    if (fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput)

                } catch (conversionError) {

                    console.error('Error en conversión:', conversionError)

                    // Fallback: enviar como documento

                    await conn.sendMessage(m.chat, {

                        audio: { url: dl.result.download },

                        mimetype: 'audio/mpeg',

                        fileName: `${title}.mp3`

                    }, { quoted: fkontak })

                }

            }

            await m.react('✅')

            return

        }

        // YTMP4 - Video

        if (command === 'ytmp4') {

            await conn.reply(m.chat, `╭━━━━━━━━━━━━━╮

│ ⏳ *جاري التحميل...*

╰━━━━━━━━━━━━━╯

📹 *${title}*

⚡ _جارٍ معالجة الفيديو..._

🎬 _قد يستغرق بضع دقائق..._

`, m)

            const dl = await downloadWithFallback(url, 'video')

            if (!dl.status) throw dl.error || '❌ Error al descargar'

            const size = await getSize(dl.result.download)

            console.log(`📦 Tamaño: ${formatSize(size)}`)

            const fkontak = {

                key: { fromMe: false, participant: "0@s.whatsapp.net" },

                message: {

                    documentMessage: {

                        title: `🎬「 ${title} 」⚡`,

                        fileName: `𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝`,

                        jpegThumbnail: thumbResized

                    }

                }

            }

            if (size > 200 * 1024 * 1024) {

                throw `📦 الفيديو كبير جدًا (${formatSize(size)}).

💡 استخدم: ${usedPrefix}ytmp4doc ${url}`

            }

            await conn.sendMessage(m.chat, {

                video: { url: dl.result.download },

                mimetype: 'video/mp4',

                caption: `🎬 *${title}*`,

                jpegThumbnail: thumbResized

            }, { quoted: fkontak })

            await m.react('✅')

            return

        }

        // YTMP3DOC - Audio como documento

        if (command === 'ytmp3doc') {

            await conn.reply(m.chat, `╭━━━━━━━━━━━━━╮

│ 💿 *جاري التحميل...*

╰━━━━━━━━━━━━━╯

🎵 *${title}*

📄 _الصيغة: ملف MP3_

⚡ _جارٍ معالجة الصوت..._

⏳ _قد تستغرق الملفات الكبيرة وقتًا أطول..._

`, m)

            const dl = await downloadWithFallback(url, 'audio')

            if (!dl.status) throw dl.error || '❌ Error al descargar'

            const size = await getSize(dl.result.download)

            const fkontak = {

                key: { fromMe: false, participant: "0@s.whatsapp.net" },

                message: {

                    documentMessage: {

                        title: `👑「 ${title} 」📿`,

                        fileName: `𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝`,

                        jpegThumbnail: thumbResized

                    }

                }

            }

            await conn.sendMessage(m.chat, {

                document: { url: dl.result.download },

                mimetype: 'audio/mpeg',

                fileName: `${title}.mp3`,

                caption: `${title}`,

                jpegThumbnail: thumbResized

            }, { quoted: fkontak })

            await m.react('✅')

            return

        }

        // YTMP4DOC - Video como documento

        if (command === 'ytmp4doc') {

            await conn.reply(m.chat, `╭━━━━━━━━━━━━━╮

│ 🎥 *جاري التحميل...*

╰━━━━━━━━━━━━━╯

📹 ${title}

📄 _الصيغة: ملف MP4_

⚡ _جارٍ معالجة الفيديو..._

⏳ _قد تستغرق الملفات الكبيرة وقتًا أطول..._

`, m)

            const dl = await downloadWithFallback(url, 'video')

            if (!dl.status) throw dl.error || '❌ Error al descargar'

            const size = await getSize(dl.result.download)

            if (size > 600 * 1024 * 1024) {

                throw `📦 الفيديو كبير جدًا (${formatSize(size)}).

⚠️ الملف يتجاوز 600 ميجابايت، لا أستطيع إرساله.`

            }

            const fkontak = {

                key: { fromMe: false, participant: "0@s.whatsapp.net" },

                message: {

                    documentMessage: {

                        title: `🎬「 ${title} 」⚡`,

                        fileName: `Descargas MeliodasBot`,

                        jpegThumbnail: thumbResized

                    }

                }

            }

            await conn.sendMessage(m.chat, {

                document: { url: dl.result.download },

                mimetype: 'video/mp4',

                fileName: `${title}.mp4`,

                jpegThumbnail: thumbResized,

                caption: `🎬 *${title}*`

            }, { quoted: fkontak })

            await m.react('✅')

            return

        }

    } catch (e) {

        await m.react('❌')

        console.error('❌ Error:', e)

        return conn.reply(m.chat, typeof e === 'string' ? e : `❌ Error: ${e.message}`, m)

    }

}

handler.help = ['شغل', 'ytmp3', 'ytmp4', 'ytmp3doc', 'ytmp4doc']

handler.tags = ['descargas']

handler.command = ['شغل', 'ytmp3', 'ytmp4', 'ytmp3doc', 'ytmp4doc']

handler.register = false

handler.group = false

export default handler