import { prepareWAMessageMedia } from '@whiskeysockets/baileys';

let handler = async (m, { conn }) => {
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
*↷─────〔 🌳 〕─────↶*
*مـࢪحـبـاََ ¦ ${taguser} ¦ 💖*
*قـسـم الـصـور*
*↷─────〔  🌳 〕─────↶*

∘₊✧──────🌹──────✧₊∘
> ✘ هـيـنـاتـا
> ✘ مــيـكـاسـا
> ✘ كــابـلـز
> ✘ تــطـقـيـم_بـنـات
> ✘ مــيـكـو
> ✘ كــورومـي
> ✘ كــانـيـكـي
> ✘ ســاكـورا
> ✘ صــوره
> ✘ هـيـسـتـيـا
> ✘ كــاوري
∘₊✧──────🌹──────✧₊∘

قَـسٰــــم࣬ يــقَــډم࣬ صــور لـشـخـصـيــات الأنــمـي و صــور مـخـتـلـفـة مـن الإنـتـرنـت 💖📸
`;

  const emojiReaction = '📷';

  try {
    // إرسال الريأكت
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    // إرسال الصورة مع الكابشن فقط
    await conn.sendMessage(m.chat, {
      image: { url: 'https://files.catbox.moe/3i6ryn.jpg' },
      caption: message
    });

  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق2)$/i;
handler.exp = 50;
export default handler;