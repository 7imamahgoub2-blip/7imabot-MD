import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '👑', key: m.key } })

    // 🔊 رابط الصوت
    const audioUrl = 'https://files.catbox.moe/mq4qqq.mp3' // ← حط رابط الصوت هنا

    // إرسال الصوت
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: audioUrl },
        mimetype: 'audio/mpeg',
        ptt: false
      },
      { quoted: m }
    )

    const menuText = `> *@مرحبا انا برهوم مطور مليودس بوت*\n\n> 𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝🧃:`

    const imageUrl = 'https://files.catbox.moe/fwssr3.jpg'

    const nativeButtons = [
      {
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({
          display_text: 'انستجرام 📸',
          url: 'https://www.instagram.com/x9_sung_7x/profilecard/?igsh=MWcyazRpajhxZG02Zg=='
        })
      },
      {
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({
          display_text: 'المطور 👑',
          url: 'https://wa.me/201067668406'
        })
      },
      {
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({
          display_text: 'تيك 🥀',
          url: 'https://www.tiktok.com/@8e7h_d?_r=1&_t=ZS-92TT2OIqmWI'
        })
      }
    ]

    // 🖼️ تجهيز الصورة
    const media = await prepareWAMessageMedia(
      { image: { url: imageUrl } },
      { upload: conn.waUploadToServer }
    )

    const header = proto.Message.InteractiveMessage.Header.fromObject({
      hasMediaAttachment: true,
      imageMessage: media.imageMessage
    })

    // 💬 الرسالة التفاعلية
    const interactiveMessage = proto.Message.InteractiveMessage.fromObject({
      body: proto.Message.InteractiveMessage.Body.fromObject({ text: menuText }),
      header,
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: nativeButtons
      })
    })

    const msg = generateWAMessageFromContent(
      m.chat,
      { interactiveMessage },
      { userJid: conn.user.jid, quoted: m }
    )

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error('❌ خطأ في أمر المطور:', e)
    await conn.sendMessage(
      m.chat,
      {
        text: `❌ *حصل خطأ أثناء جلب المعلومات*\n\n🔗 رابط مباشر: https://wa.me/201067668406\n\n⚠️ *الخطأ:* ${e.message}`
      },
      { quoted: m }
    )
  }
}

handler.help = ['owner', 'creador']
handler.tags = ['info']
handler.command = ['المطور', 'owner', 'contacto']

export default handler