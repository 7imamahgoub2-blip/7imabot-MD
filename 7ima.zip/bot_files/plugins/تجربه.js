import fetch from 'node-fetch';
import * as cheerio from 'cheerio';

// تخزين بيانات الأخبار للمستخدمين (غير محدود)
const userNewsCache = new Map();

// الصورة الافتراضية من رابطك
const DEFAULT_IMAGE = 'https://i.postimg.cc/crs5jTsp/upload-1766119478093.jpg';

// جميع الأقسام المتاحة
const ALL_SECTIONS = {
    'home': { name: '🏠 الرئيسية', url: 'https://aawsat.com', emoji: '🏠' },
    'world': { name: '🌍 العالم', url: 'https://aawsat.com/العالم', emoji: '🌍' },
    'yemen': { name: '🇾🇪 اليمن', url: 'https://aawsat.com/tags/location-%D8%A7%D9%84%D9%8A%D9%85%D9%86', emoji: '🇾🇪' },
    'economy': { name: '💰 الاقتصاد', url: 'https://aawsat.com/الاقتصاد', emoji: '💰' },
    'sports': { name: '⚽ الرياضة', url: 'https://aawsat.com/الرياضة', emoji: '⚽' },
    'culture': { name: '🎨 الثقافة', url: 'https://aawsat.com/الثقافة', emoji: '🎨' },
    'technology': { name: '💻 التكنولوجيا', url: 'https://aawsat.com/التكنولوجيا', emoji: '💻' },
    'varieties': { name: '📱 متنوعات', url: 'https://aawsat.com/المتنوعة', emoji: '📱' }
};

let handler = async (m, { conn, usedPrefix, command }) => {
    const chatId = m.chat;
    const sender = m.sender;
    const args = m.text.split(' ').slice(1);
    const cmd = args[0] || '';
    const subCmd = args[1] || '';

    try {
        console.log(`[DEBUG] Command: ${command}, Args: ${cmd}, Sub: ${subCmd}`);

        // إظهار رد فعل التحميل
        try {
            await conn.sendMessage(chatId, { react: { text: "⏳", key: m.key } });
        } catch (e) {}

        // ============ نظام الأوامر المفتوح ============
        
        // 1. إذا كان الأمر "خبار" فقط - عرض القائمة الرئيسية
        if (!cmd) {
            await showMainMenu(m, conn, usedPrefix);
            return;
        }

        // 2. إذا كان الأمر "خبار جميع" أو "خبار كل" - عرض جميع الأقسام
        if (cmd === 'جميع' || cmd === 'كل' || cmd === 'all') {
            await showAllSections(m, conn, usedPrefix);
            return;
        }

        // 3. إذا كان الأمر "خبار بحث [كلمة]" - بحث في الأخبار
        if (cmd === 'بحث' || cmd === 'search') {
            const searchTerm = args.slice(1).join(' ') || subCmd;
            if (searchTerm) {
                await searchNews(sender, m, conn, searchTerm, usedPrefix);
            } else {
                await conn.sendMessage(chatId, {
                    text: `❌ يرجى كتابة كلمة للبحث\nمثال: ${usedPrefix}خبار بحث يمن`
                }, { quoted: m });
            }
            return;
        }

        // 4. إذا كان الأمر "خبار قسم [اسم القسم]" - عرض قسم محدد
        if (cmd === 'قسم' && subCmd) {
            await loadSection(sender, m, conn, subCmd, usedPrefix);
            return;
        }

        // 5. إذا كان الأمر "خبار [اسم القسم مباشرة]" - اختصار للأقسام
        const directSection = getSectionByAlias(cmd);
        if (directSection) {
            await loadSection(sender, m, conn, directSection, usedPrefix);
            return;
        }

        // 6. إذا كان الأمر "خبار التالي" - الصفحة التالية
        if (cmd === 'التالي') {
            await showNext(sender, m, conn, usedPrefix);
            return;
        }

        // 7. إذا كان الأمر "خبار السابق" - الصفحة السابقة
        if (cmd === 'السابق') {
            await showPrev(sender, m, conn, usedPrefix);
            return;
        }

        // 8. إذا كان الأمر "خبار تحديث" - تحديث الصفحة الحالية
        if (cmd === 'تحديث') {
            await refreshCurrent(sender, m, conn, usedPrefix);
            return;
        }

        // 9. إذا لم يتطابق أي أمر - عرض القائمة
        await showMainMenu(m, conn, usedPrefix);

    } catch (error) {
        console.error('[ERROR] Handler error:', error);
        await conn.sendMessage(chatId, {
            text: `❌ حدث خطأ: ${error.message}\n\nاستخدم "${usedPrefix}خبار" للقائمة الرئيسية.`
        }, { quoted: m });
    }
};

// ============ القائمة الرئيسية المفتوحة ============
async function showMainMenu(m, conn, usedPrefix) {
    const chatId = m.chat;
    
    try {
        const menuText = `
*📰 أخبار الشرق الأوسط - مصدر مفتوح*

*✨ نظام مفتوح بدون حدود:*
• عدد غير محدود من الأخبار
• جميع الأقسام متاحة
• بحث حر في المحتوى
• تصفح مستمر

*🚀 الأوامر المتاحة:*

1️⃣ *📋 القائمة الرئيسية*
   ↳ ${usedPrefix}خبار

2️⃣ *🌐 جميع الأقسام*
   ↳ ${usedPrefix}خبار جميع

3️⃣ *🔍 بحث في الأخبار*
   ↳ ${usedPrefix}خبار بحث [كلمة]

4️⃣ *📰 قسم محدد*
   ↳ ${usedPrefix}خبار قسم [اسم القسم]

5️⃣ *🔄 تحديث الأخبار*
   ↳ ${usedPrefix}خبار تحديث

6️⃣ *⏭️ تصفح الأخبار*
   ↳ ${usedPrefix}خبار التالي
   ↳ ${usedPrefix}خبار السابق

*📊 مثال سريع:*
${usedPrefix}خبار قسم يمن
${usedPrefix}خبار بحث اقتصاد
${usedPrefix}خبار جميع

━━━━━━━━━━━━━━━━━━━━━━
⚡ *مصدر مفتوح - غير محدود*`;

        await conn.sendMessage(chatId, {
            image: { url: DEFAULT_IMAGE },
            caption: menuText,
            footer: '📰 الشرق الأوسط - مصدر مفتوح بدون قيود',
            buttons: [
                { buttonId: `${usedPrefix}خبار جميع`, buttonText: { displayText: "🌐 جميع الأقسام" }, type: 1 },
                { buttonId: `${usedPrefix}خبار قسم يمن`, buttonText: { displayText: "🇾🇪 أخبار اليمن" }, type: 1 },
                { buttonId: `${usedPrefix}خبار قسم اقتصاد`, buttonText: { displayText: "💰 أخبار الاقتصاد" }, type: 1 },
                { buttonId: `${usedPrefix}خبار قسم رياضة`, buttonText: { displayText: "⚽ أخبار الرياضة" }, type: 1 },
                { buttonId: `${usedPrefix}خبار بحث`, buttonText: { displayText: "🔍 بحث في الأخبار" }, type: 1 }
            ],
            headerType: 1
        }, { quoted: m });

        try {
            await conn.sendMessage(chatId, { react: { text: "✅", key: m.key } });
        } catch (e) {}

    } catch (error) {
        console.error('[ERROR] Menu error:', error);
        await conn.sendMessage(chatId, {
            text: menuText + '\n\n' + '❌ فشل في تحميل الصورة، ولكن يمكنك متابعة استخدام النظام.'
        }, { quoted: m });
    }
}

// ============ عرض جميع الأقسام ============
async function showAllSections(m, conn, usedPrefix) {
    const chatId = m.chat;
    
    try {
        let sectionsText = '*🌐 جميع أقسام الشرق الأوسط*\n\n';
        
        Object.entries(ALL_SECTIONS).forEach(([id, section], index) => {
            sectionsText += `${index + 1}. ${section.emoji} *${section.name}*\n`;
            sectionsText += `   ↳ ${usedPrefix}خبار قسم ${id}\n\n`;
        });

        sectionsText += `*📋 إجمالي الأقسام:* ${Object.keys(ALL_SECTIONS).length} قسم\n`;
        sectionsText += `*⚡ جميعها متاحة للاستخدام الفوري*\n\n`;
        sectionsText += `━━━━━━━━━━━━━━━━━━━━━━\n`;
        sectionsText += `*💡 استخدم الأمر مباشرة مثل:*\n`;
        sectionsText += `${usedPrefix}خبار قسم يمن\n`;
        sectionsText += `${usedPrefix}خبار قسم اقتصاد\n`;
        sectionsText += `${usedPrefix}خبار قسم رياضة`;

        await conn.sendMessage(chatId, {
            image: { url: DEFAULT_IMAGE },
            caption: sectionsText,
            footer: 'اختر أي قسم وابدأ التصفح',
            buttons: Object.entries(ALL_SECTIONS).slice(0, 5).map(([id, section]) => ({
                buttonId: `${usedPrefix}خبار قسم ${id}`,
                buttonText: { displayText: `${section.emoji} ${section.name.split(' ')[1] || section.name}` },
                type: 1
            }))
        }, { quoted: m });

    } catch (error) {
        console.error('[ERROR] All sections error:', error);
        await conn.sendMessage(chatId, {
            text: sectionsText
        }, { quoted: m });
    }
}

// ============ تحميل قسم معين ============
async function loadSection(userId, m, conn, sectionId, usedPrefix) {
    const chatId = m.chat;
    
    try {
        const section = ALL_SECTIONS[sectionId];
        if (!section) {
            // إذا لم يكن القسم معروفاً، نبحث في كل الأقسام
            await searchInAllSections(userId, m, conn, sectionId, usedPrefix);
            return;
        }

        console.log(`[OPEN-SOURCE] Loading section: ${section.name} from ${section.url}`);

        // جلب الأخبار بدون حدود
        const newsData = await fetchUnlimitedNews(section.url);
        
        if (!newsData || newsData.length === 0) {
            await conn.sendMessage(chatId, {
                image: { url: DEFAULT_IMAGE },
                caption: `*📭 قسم ${section.name}*\n\nلا توجد أخبار حالياً في هذا القسم.\n\nجرب:\n• ${usedPrefix}خبار جميع - لعرض جميع الأقسام\n• ${usedPrefix}خبار بحث [كلمة] - للبحث في الأخبار`,
                footer: 'الشرق الأوسط - مصدر مفتوح'
            }, { quoted: m });
            return;
        }

        // تخزين البيانات بدون حدود
        userNewsCache.set(userId, {
            items: newsData,
            currentIndex: 0,
            sectionId: sectionId,
            sectionName: section.name,
            sectionEmoji: section.emoji,
            type: 'section',
            timestamp: Date.now(),
            // إضافة معلومات إضافية للمصدر المفتوح
            totalItems: newsData.length,
            source: 'الشرق الأوسط',
            isUnlimited: true
        });

        // عرض الصفحة الأولى
        await showUnlimitedPage(userId, m, conn, 0, usedPrefix);

        try {
            await conn.sendMessage(chatId, { react: { text: "📰", key: m.key } });
        } catch (e) {}

    } catch (error) {
        console.error('[ERROR] Section load error:', error);
        await conn.sendMessage(chatId, {
            text: `❌ فشل تحميل القسم: ${sectionId}\nالخطأ: ${error.message}\n\nجرب قسم آخر: ${usedPrefix}خبار جميع`
        }, { quoted: m });
    }
}

// ============ البحث في جميع الأقسام ============
async function searchInAllSections(userId, m, conn, searchTerm, usedPrefix) {
    const chatId = m.chat;
    
    try {
        await conn.sendMessage(chatId, { react: { text: "🔍", key: m.key } });
        
        let allResults = [];
        let sectionsChecked = 0;
        
        // البحث في جميع الأقسام
        for (const [id, section] of Object.entries(ALL_SECTIONS)) {
            try {
                const newsData = await fetchUnlimitedNews(section.url);
                const filteredResults = newsData.filter(item => 
                    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    item.description.toLowerCase().includes(searchTerm.toLowerCase())
                );
                
                if (filteredResults.length > 0) {
                    filteredResults.forEach(item => {
                        item.section = section.name;
                        item.sectionEmoji = section.emoji;
                    });
                    allResults = [...allResults, ...filteredResults];
                }
                
                sectionsChecked++;
                
            } catch (error) {
                console.error(`[SEARCH] Error in section ${id}:`, error);
            }
        }

        if (allResults.length === 0) {
            await conn.sendMessage(chatId, {
                image: { url: DEFAULT_IMAGE },
                caption: `*🔍 نتائج البحث: "${searchTerm}"*\n\nلم يتم العثور على نتائج.\n\nجرب:\n• استخدام كلمات أخرى\n• ${usedPrefix}خبار جميع - لعرض جميع الأقسام\n• ${usedPrefix}خبار - للقائمة الرئيسية`,
                footer: 'الشرق الأوسط - بحث مفتوح'
            }, { quoted: m });
            return;
        }

        // تخزين نتائج البحث
        userNewsCache.set(userId, {
            items: allResults,
            currentIndex: 0,
            searchTerm: searchTerm,
            type: 'search',
            timestamp: Date.now(),
            totalItems: allResults.length,
            isUnlimited: true,
            sectionsChecked: sectionsChecked
        });

        // عرض نتائج البحث
        await showSearchResults(userId, m, conn, 0, usedPrefix);

        try {
            await conn.sendMessage(chatId, { react: { text: "✅", key: m.key } });
        } catch (e) {}

    } catch (error) {
        console.error('[ERROR] Search error:', error);
        await conn.sendMessage(chatId, {
            text: `❌ فشل البحث: ${error.message}`
        }, { quoted: m });
    }
}

// ============ البحث المخصص ============
async function searchNews(userId, m, conn, searchTerm, usedPrefix) {
    await searchInAllSections(userId, m, conn, searchTerm, usedPrefix);
}

// ============ جلب أخبار غير محدودة ============
async function fetchUnlimitedNews(url) {
    try {
        console.log(`[UNLIMITED] Fetching from: ${url}`);
        
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'ar,en;q=0.9',
                'Referer': 'https://aawsat.com/'
            },
            timeout: 20000 // وقت أطول للمصدر المفتوح
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const html = await response.text();
        const $ = cheerio.load(html);
        
        const newsItems = [];

        // طريقة شاملة لجمع كل المحتوى الممكن
        const contentSelectors = [
            'article', '.c-article', '.article-card', '.news-item',
            '.c-card', '[class*="article"]', '[class*="news"]',
            '.post', '.story', '.item'
        ];

        // جمع جميع العناصر الممكنة
        contentSelectors.forEach(selector => {
            $(selector).each((i, elem) => {
                const $elem = $(elem);
                
                // العنوان
                const titleElem = $elem.find('h1, h2, h3, h4, .title, .headline, .c-title').first();
                let title = titleElem.text().trim();
                
                if (!title || title.length < 5) return;
                
                // الرابط
                let link = $elem.find('a').attr('href') || titleElem.parents('a').attr('href');
                if (link && !link.startsWith('http')) {
                    link = `https://aawsat.com${link}`;
                }
                
                // الوصف
                let description = $elem.find('.description, .excerpt, .summary, .content, p').first().text().trim();
                if (description.length > 150) {
                    description = description.substring(0, 147) + '...';
                }
                
                // الصورة
                let image = $elem.find('img').attr('src') || $elem.find('img').attr('data-src');
                if (image && !image.startsWith('http')) {
                    image = `https://aawsat.com${image}`;
                }
                
                // الوقت
                let time = $elem.find('time, .date, .timestamp, .c-time, .published').first().text().trim();
                
                // تنظيف
                title = title.replace(/\s+/g, ' ').replace(/\n/g, ' ').trim();
                
                // تجنب التكرار
                const exists = newsItems.some(item => item.title === title);
                if (!exists) {
                    newsItems.push({
                        title: title,
                        description: description || 'أخبار من الشرق الأوسط',
                        link: link || url,
                        image: image || DEFAULT_IMAGE,
                        time: time || 'قريباً',
                        source: 'الشرق الأوسط',
                        timestamp: Date.now()
                    });
                }
            });
        });

        // إذا لم نجد الكثير، نجمع العناوين مباشرة
        if (newsItems.length < 10) {
            $('h1, h2, h3').each((i, elem) => {
                const title = $(elem).text().trim();
                if (title && title.length > 10 && 
                    !title.includes('©') && 
                    !title.includes('سياسة') &&
                    !title.includes('خصوصية') &&
                    !title.includes('اشترك')) {
                    
                    newsItems.push({
                        title: title,
                        description: 'أخبار من الشرق الأوسط',
                        link: url,
                        image: DEFAULT_IMAGE,
                        time: 'قريباً',
                        source: 'الشرق الأوسط',
                        timestamp: Date.now()
                    });
                }
            });
        }

        console.log(`[UNLIMITED] Found ${newsItems.length} items`);
        return newsItems; // إرجاع كل شيء بدون حدود

    } catch (error) {
        console.error('[ERROR] Unlimited fetch error:', error);
        return [];
    }
}

// ============ عرض صفحة غير محدودة ============
async function showUnlimitedPage(userId, m, conn, startIndex, usedPrefix) {
    const chatId = m.chat;
    const userData = userNewsCache.get(userId);
    
    if (!userData) {
        await conn.sendMessage(chatId, {
            text: '❌ لا توجد بيانات. استخدم `.خبار` للبدء.'
        }, { quoted: m });
        return;
    }

    const { items, sectionName, sectionEmoji, type, searchTerm, totalItems } = userData;
    const itemsPerPage = 5; // زيادة العدد في المصدر المفتوح
    const endIndex = Math.min(startIndex + itemsPerPage, items.length);
    
    if (startIndex >= items.length) {
        await conn.sendMessage(chatId, {
            image: { url: DEFAULT_IMAGE },
            caption: `*🏁 نهاية المحتوى*\n\nعرضت ${items.length} خبر من ${totalItems} خبر.\n\nاستخدم:\n• ${usedPrefix}خبار جميع - لأقسام أخرى\n• ${usedPrefix}خبار بحث [كلمة] - للبحث\n• ${usedPrefix}خبار - للقائمة`,
            footer: 'مصدر مفتوح - غير محدود'
        }, { quoted: m });
        return;
    }

    // بناء الرسالة
    let message = '';
    
    if (type === 'search') {
        message += `*🔍 نتائج البحث: "${searchTerm}"*\n`;
        message += `📊 ${items.length} نتيجة | الصفحة ${Math.floor(startIndex/itemsPerPage) + 1}\n`;
    } else {
        message += `*${sectionEmoji} ${sectionName}*\n`;
        message += `📊 ${items.length} خبر | الصفحة ${Math.floor(startIndex/itemsPerPage) + 1}\n`;
    }
    
    message += `⏰ ${new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}\n`;
    message += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    // إضافة الأخبار
    for (let i = startIndex; i < endIndex; i++) {
        const item = items[i];
        message += `*${i + 1}. ${item.title}*\n`;
        
        if (item.description && item.description !== 'أخبار من الشرق الأوسط') {
            message += `📝 ${item.description}\n`;
        }
        
        if (item.time && item.time !== 'قريباً') {
            message += `🕒 ${item.time}\n`;
        }
        
        if (type === 'search' && item.section) {
            message += `📂 ${item.sectionEmoji} ${item.section}\n`;
        }
        
        message += `🔗 ${item.link}\n`;
        
        if (i < endIndex - 1) {
            message += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        }
    }

    message += `\n━━━━━━━━━━━━━━━━━━━━━━\n`;
    message += `*${startIndex + 1}-${endIndex} من ${items.length}*`;

    // الأزرار المفتوحة
    const buttons = [];

    // زر السابق
    if (startIndex > 0) {
        buttons.push({
            buttonId: `${usedPrefix}خبار السابق`,
            buttonText: { displayText: "◀️ السابق" },
            type: 1
        });
    }

    // زر التالي
    if (endIndex < items.length) {
        buttons.push({
            buttonId: `${usedPrefix}خبار التالي`,
            buttonText: { displayText: "▶️ التالي" },
            type: 1
        });
    }

    // زر تحديث
    buttons.push({
        buttonId: `${usedPrefix}خبار تحديث`,
        buttonText: { displayText: "🔄 تحديث" },
        type: 1
    });

    // زر القائمة
    buttons.push({
        buttonId: `${usedPrefix}خبار`,
        buttonText: { displayText: "📋 القائمة" },
        type: 1
    });

    // زر البحث
    buttons.push({
        buttonId: `${usedPrefix}خبار بحث`,
        buttonText: { displayText: "🔍 بحث جديد" },
        type: 1
    });

    try {
        const firstItem = items[startIndex];
        await conn.sendMessage(chatId, {
            image: { url: firstItem?.image || DEFAULT_IMAGE },
            caption: message,
            footer: 'مصدر مفتوح | استخدم الأزرار للتحكم',
            buttons: buttons,
            headerType: 1
        }, { quoted: m });
        
    } catch (error) {
        console.error('[ERROR] Send error:', error);
        await conn.sendMessage(chatId, {
            text: `${message}\n\n*أوامر:*\n◀️ ${usedPrefix}خبار السابق\n▶️ ${usedPrefix}خبار التالي\n🔄 ${usedPrefix}خبار تحديث\n📋 ${usedPrefix}خبار\n🔍 ${usedPrefix}خبار بحث [كلمة]`
        }, { quoted: m });
    }

    // تحديث المؤشر
    userNewsCache.set(userId, {
        ...userData,
        currentIndex: startIndex
    });
}

// ============ عرض نتائج البحث ============
async function showSearchResults(userId, m, conn, startIndex, usedPrefix) {
    await showUnlimitedPage(userId, m, conn, startIndex, usedPrefix);
}

// ============ الصفحة التالية ============
async function showNext(userId, m, conn, usedPrefix) {
    const userData = userNewsCache.get(userId);
    if (!userData) {
        await conn.sendMessage(m.chat, {
            text: '❌ لا توجد بيانات. استخدم `.خبار` للبدء.'
        }, { quoted: m });
        return;
    }

    const itemsPerPage = 5;
    const nextIndex = userData.currentIndex + itemsPerPage;
    
    if (userData.type === 'search') {
        await showSearchResults(userId, m, conn, nextIndex, usedPrefix);
    } else {
        await showUnlimitedPage(userId, m, conn, nextIndex, usedPrefix);
    }
}

// ============ الصفحة السابقة ============
async function showPrev(userId, m, conn, usedPrefix) {
    const userData = userNewsCache.get(userId);
    if (!userData) {
        await conn.sendMessage(m.chat, {
            text: '❌ لا توجد بيانات. استخدم `.خبار` للبدء.'
        }, { quoted: m });
        return;
    }

    const itemsPerPage = 5;
    const prevIndex = Math.max(0, userData.currentIndex - itemsPerPage);
    
    if (prevIndex === userData.currentIndex) {
        await conn.sendMessage(m.chat, {
            text: '✅ أنت في الصفحة الأولى.'
        }, { quoted: m });
        return;
    }

    if (userData.type === 'search') {
        await showSearchResults(userId, m, conn, prevIndex, usedPrefix);
    } else {
        await showUnlimitedPage(userId, m, conn, prevIndex, usedPrefix);
    }
}

// ============ تحديث الصفحة الحالية ============
async function refreshCurrent(userId, m, conn, usedPrefix) {
    const userData = userNewsCache.get(userId);
    if (!userData) {
        await conn.sendMessage(m.chat, {
            text: '❌ لا توجد بيانات. استخدم `.خبار` للبدء.'
        }, { quoted: m });
        return;
    }

    try {
        await conn.sendMessage(m.chat, { react: { text: "🔄", key: m.key } });
        
        if (userData.type === 'search') {
            await searchInAllSections(userId, m, conn, userData.searchTerm, usedPrefix);
        } else {
            await loadSection(userId, m, conn, userData.sectionId, usedPrefix);
        }
    } catch (error) {
        await conn.sendMessage(m.chat, {
            text: `❌ فشل التحديث: ${error.message}`
        }, { quoted: m });
    }
}

// ============ دوال مساعدة ============
function getSectionByAlias(alias) {
    const aliases = {
        'عالم': 'world', 'العالم': 'world',
        'يمن': 'yemen', 'اليمن': 'yemen',
        'اقتصاد': 'economy', 'الاقتصاد': 'economy',
        'رياضة': 'sports', 'الرياضة': 'sports',
        'رئيسية': 'home', 'الرئيسية': 'home',
        'ثقافة': 'culture', 'الثقافة': 'culture',
        'تكنولوجيا': 'technology', 'التكنولوجيا': 'technology',
        'متنوعات': 'varieties', 'المتنوعة': 'varieties',
        'home': 'home', 'world': 'world',
        'yemen': 'yemen', 'economy': 'economy',
        'sports': 'sports', 'culture': 'culture',
        'tech': 'technology', 'variety': 'varieties'
    };
    
    return aliases[alias.toLowerCase()] || null;
}

// ============ إعدادات الهاندلر المفتوحة ============
handler.help = [
    'خبار',
    'خبار جميع',
    'خبار قسم [اسم]',
    'خبار بحث [كلمة]',
    'خبار التالي',
    'خبار السابق',
    'خبار تحديث'
];

handler.tags = ['news', 'tools', 'open-source'];
handler.command = /^خبار$/i;

handler.info = {
    name: 'أخبار الشرق الأوسط - مصدر مفتوح',
    description: 'نظام أخبار مفتوح بدون حدود مع بحث وتصفح حر',
    usage: `.خبار - القائمة الرئيسية
.خبار جميع - جميع الأقسام
.خبار قسم [اسم] - قسم محدد
.خبار بحث [كلمة] - بحث في الأخبار
.خبار التالي/السابق - التصفح
.خبار تحديث - تحديث الصفحة`,
    example: `.خبار
.خبار جميع
.خبار قسم يمن
.خبار بحث اقتصاد
.خبار التالي`,
    category: 'الأخبار المفتوحة'
};

// إعدادات مفتوحة بدون قيود
handler.limit = false;      // لا حدود للاستخدام
handler.premium = false;    // مجاني للجميع
handler.group = true;       // يعمل في المجموعات فقط
// تم إزالة handler.private = true; -  يعمل في المجموعات فقط

export default handler;