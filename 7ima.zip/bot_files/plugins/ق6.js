let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
*↷─────〔 🌳 〕─────↶*
*مـࢪحـبـاََ ¦ ${taguser} ¦ 💖*
*قـسـم الـبـنـك*
*↷─────〔  🌳 〕─────↶*

∘₊✧──────🌹──────✧₊∘
> ✘ يـومـي
> ✘ أسـبـوعـي
> ✘ عـمـل
> ✘ راتـب
> ✘ رانـك
> ✘ مـحـفـظـة
> ✘ عـمـلاتـي
> ✘ شـراء/تـسـوق
> ✘ عـمـلات
> ✘ المـاس
> ✘ سـحـب
> ✘ ايـداع
> ✘ بــنــك
> ✘ رهـان
> ✘ هـجـوم
> ✘ أنـا
∘₊✧──────🌹──────✧₊∘

قَـسٰــــم࣬ يــقَــډم࣬ أوامـــر البنك و الفلوس و التعامل مع العملات 💖❄️
`;

  const emojiReaction = '❄️';

  try {
    // إرسال الريأكت
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    // إرسال الصورة مع الكابشن فقط
    await conn.sendMessage(m.chat, {
      image: { url: 'https://files.catbox.moe/3i6ryn.jpg' },
      caption: message,
      mentions: [m.sender]
    });

  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق6)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;