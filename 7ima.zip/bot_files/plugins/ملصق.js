import { sticker } from '../lib/sticker.js'
import uploadFile from '../lib/uploadFile.js'
import uploadImage from '../lib/uploadImage.js'
import { webp2png } from '../lib/webp2mp4.js'
import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, args }) => {
  let stiker = null
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || q.mediaType || ''

    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp')

    if (/webp|image|video/g.test(mime)) {

      if (/video/.test(mime) && ((q.msg || q).seconds > 8)) {
        return m.reply('⚠️ مدة الفيديو يجب ألا تتجاوز *8 ثواني*.')
      }

      const media = await q.download()
      if (!media) return m.reply('❌ لم أستطع استلام الملف، تأكد أنك رددت على صورة أو فيديو.')

      try {
        stiker = await sticker(
          media,
          false,
          'Barhoum',
          '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝'
        )
      } catch (e) {
        let out
        if (/webp/.test(mime)) out = await webp2png(media)
        else if (/image/.test(mime)) out = await uploadImage(media)
        else if (/video/.test(mime)) out = await uploadFile(media)

        if (typeof out !== 'string') out = await uploadImage(media)

        stiker = await sticker(
          false,
          out,
          'Barhoum',
          '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝'
        )
      }

    } else if (args[0]) {

      if (!isUrl(args[0])) return m.reply('📛 الرابط غير صالح! يجب أن يكون صورة مباشرة.')

      stiker = await sticker(
        false,
        args[0],
        'Barhoum',
        '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝'
      )

    } else {
      return m.reply('📌 أرسل / رد على صورة - فيديو (8 ثواني) - أو اكتب رابط لتحويله لملصق.')
    }

  } catch (e) {
    console.error('❌ خطأ أثناء إنشاء الملصق:', e)
    return m.reply('⚠️ حدث خطأ غير متوقع أثناء إنشاء الملصق.')
  }

  if (stiker) {
    try {
      const imgFolder = './src/img'
      let contextInfo = {}

      if (fs.existsSync(imgFolder)) {
        const files = fs.readdirSync(imgFolder).filter(f => /\.(jpe?g|png|webp)$/i.test(f))
        if (files.length > 0) {
          contextInfo = {
            externalAdReply: {
              title: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝',
              body: '⚡ تم إنشاء الملصق بنجاح',
              mediaType: 2,
              thumbnail: fs.readFileSync(path.join(imgFolder, files[Math.floor(Math.random() * files.length)])),
            }
          }
        }
      }

      await conn.sendMessage(m.chat, { sticker: stiker, contextInfo }, { quoted: m })

    } catch (e) {
      console.error('⚠️ خطأ أثناء الإرسال:', e)
      return m.reply('❌ لم أستطع إرسال الملصق، حاول مرة أخرى.')
    }
  }
}

handler.help = ['ملصق', 'استيكر', 'تحويل', 's']
handler.tags = ['sticker']
handler.command = ['ملصق', 'استيكر', 'تحويل', 'ملصقة', 's']

export default handler

function isUrl(text) {
  return /^https?:\/\/.*\.(jpe?g|gif|png|webp)$/i.test(text)
}