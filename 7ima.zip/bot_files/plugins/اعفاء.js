let handler = async (m, { conn, usedPrefix, command, text }) => {
  if(isNaN(text) && !text.match(/@/g)){}else if(isNaN(text)) {
    var number = text.split`@`[1]
  }else if(!isNaN(text)) {
    var number = text
  }
  
  if(!text && !m.quoted) return conn.sendMessage(m.chat, { text: `*مـنـشن الــشـخص !*`, contextInfo: { isForwarded: true, forwardingScore: 999, forwardedNewsletterMessageInfo: { newsletterJid: '120363422420713361@newsletter', newsletterName: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝 🔥', serverMessageId: 100 } } }, { quoted: m })
  
  if(number.length > 13 || (number.length < 11 && number.length > 0)) return conn.sendMessage(m.chat, { text: `*الـرقـم غـلط !*`, contextInfo: { isForwarded: true, forwardingScore: 999, forwardedNewsletterMessageInfo: { newsletterJid: '120363422420713361@newsletter', newsletterName: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝🔥', serverMessageId: 100 } } }, { quoted: m })
  
  try {
    if(text) {
      var user = number + '@s.whatsapp.net'
    } else if(m.quoted.sender) {
      var user = m.quoted.sender
    } else if(m.mentionedJid) {
      var user = number + '@s.whatsapp.net'
    }
  } catch (e) {}
  finally {
    conn.groupParticipantsUpdate(m.chat, [user], 'demote')
    conn.sendMessage(m.chat, { text: `*تـــم الــأعــفـاء !*`, contextInfo: { isForwarded: true, forwardingScore: 999, forwardedNewsletterMessageInfo: { newsletterJid: '120363422420713361@newsletter', newsletterName: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝🔥', serverMessageId: 100 } } }, { quoted: m })
  }
}

handler.help = ['demote (@tag)']
handler.tags = ['group']
handler.command = ['خفض', 'اعفاء']
handler.group = true
handler.admin = true
handler.botAdmin = true
handler.fail = null
export default handler