let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `*⎔ ⋅ ───━ •﹝❄﹞• ━─── ⋅ ⎔*\n*⌝ امر الابلاغ ┋📚⌞*\n*المرجو تقديم بعد الأمر .ابلاغ مشكلتك التي تواجها في البوت 🤝💗*\n> على سبيل المثال : .ابلاغ مشكله في أمر تحميل من فيسبوك الأمر .فبسبوك\n*⎔ ⋅ ───━ •﹝❄﹞• ━─── ⋅ ⎔*`
if (text.length < 6) throw `يا اخي البلاغ يجب يكون +6 حروف لي قبوله 💎📜`
if (text.length > 100000) throw `البلاغ لا يزيد عن مئة الف حرف*`
let teks = `*⎔ ⋅ ───━ •﹝❄﹞• ━─── ⋅ ⎔*\n*🕋┊الرقم┊⇇『 wa.me/${m.sender.split`@`[0]} 』*\n*🕋┊البلاغ┊⇇『 ${text} 』*\n*⎔ ⋅ ───━ •﹝❄﹞• ━─── ⋅ ⎔*`
conn.reply('201067668406@s.whatsapp.net', m.quoted ? teks + m.quoted.text : teks, null, { contextInfo: { mentionedJid: [m.sender] }})
conn.reply('@s.whatsapp.net', m.quoted ? teks + m.quoted.text : teks, null, { contextInfo: { mentionedJid: [m.sender] }})
m.reply(`*∞┇━━━ •『❄』• ━━━┇∞*\nتم ارسال البلاغ لي المطورين يا اخي 😶⚜💛\n*∞┇━━━ •『❄』• ━━━┇∞*`)
}
handler.help = ['reporte', 'request'].map(v => v + ' <teks>')
handler.tags = ['info']
handler.command = /^(report|بلاغ|بلغ|ابلاغ|bug|report-owner|reportes)$/i
export default handler;