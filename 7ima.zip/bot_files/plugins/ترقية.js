var handler = async (m, { conn }) => {

  let mentionedJid =
    m.mentionedJid?.[0] ||
    m._mentionedJidResolved?.[0] ||
    m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
    m.quoted?.sender ||
    null

  if (!mentionedJid) {
    return conn.reply(
      m.chat,
      `⚠️ منشن العضو أو رد على رسالته لترقيته.`,
      m
    )
  }

  try {
    const groupInfo = await conn.groupMetadata(m.chat)
    const ownerGroup =
      groupInfo.owner || m.chat.split('-')[0] + '@s.whatsapp.net'
    const ownerBot =
      global.owner?.[0]?.[0] + '@s.whatsapp.net'

    // منع ترقية البوت
    if (mentionedJid === conn.user.jid)
      return conn.reply(m.chat, `🤖 لا أستطيع ترقية نفسي.`, m)

    // منع ترقية مالك الجروب (هو أدمن أصلاً)
    if (mentionedJid === ownerGroup)
      return conn.reply(m.chat, `👑 مالك المجموعة أدمن بالفعل.`, m)

    // التحقق أن المستخدم ليس أدمن
    const userIsAdmin = groupInfo.participants.some(
      p => p.id === mentionedJid && p.admin
    )

    if (userIsAdmin) {
      return conn.reply(
        m.chat,
        `🚫 هذا المستخدم أدمن بالفعل.`,
        m
      )
    }

    await conn.groupParticipantsUpdate(
      m.chat,
      [mentionedJid],
      'promote'
    )

    await conn.reply(
      m.chat,
      `⬆️ تم ترقية @${mentionedJid.split('@')[0]} إلى أدمن بنجاح.`,
      m,
      { mentions: [mentionedJid] }
    )

  } catch (e) {
    conn.reply(
      m.chat,
      `⚠️ حدث خطأ أثناء تنفيذ الأمر.\n\n${e.message}`,
      m
    )
  }
}

handler.help = ['ترقية', 'promote']
handler.tags = ['group', 'ترفيه']
handler.command = ['ترقية', 'ادمن', 'مشرف', 'promote']
handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler