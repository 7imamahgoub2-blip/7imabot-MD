let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
*↷─────〔 🌳 〕─────↶*
*مـࢪحـبـاََ ¦ ${taguser} ¦ 💖*
*قـسـم الـAI*
𝒘𝒆𝒍𝒄𝒐𝒎𝒆 𝒕𝒐 𝒂𝒊 ↝| 
𝒔𝒂𝒊𝒏𝒐𝒂 𝒃𝒐𝒕 🍓
𝒊 𝒍𝒐𝒗𝒆 ↝| 𝒎𝒆 𝒏𝒐𝒕 𝒚𝒐𝒖 😹
𝒑𝒍 𝒔𝒂𝒄 𝒕𝒐 𝒎𝒚 𝒄𝒉𝒂 🥰
*↷─────〔  🌳 〕─────↶*

∘₊✧──────🌹──────✧₊∘
> ✘ أيـتـاتـشي ࿄ ➥
> ✘ لـيـنا ➥
> ✘ هـالك ➥ᷜ
> ✘ لـوفي ➥
> ✘ سـنٰــوٰۿ ➥
> ✘ ديـنـي ➥
∘₊✧──────🌹──────✧₊∘

قَـسٰــــم࣬ يــقَــډم࣬ أوامـــر و أدوات الذكاء الاصطناعي 💖🌙
`;

  const emojiReaction = '🌙';

  try {
    // إرسال الريأكت
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    // إرسال الصورة مع الكابشن فقط
    await conn.sendMessage(m.chat, {
      image: { url: 'https://files.catbox.moe/3i6ryn.jpg' },
      caption: message,
      mentions: [m.sender]
    });

  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق7)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;