// تـم كـود تـنـصـيـب عـربي مـزخرف

// كـود صالـح مع البـنيـه الجـديده 

// BY  𝑵𝒂𝒈𝒊 🌿

const { useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestBaileysVersion } = (await import("@whiskeysockets/baileys"))

import qrcode from "qrcode"

import NodeCache from "node-cache"

import fs from "fs"

import path from "path"

import pino from 'pino'

import chalk from 'chalk'

import util from 'util'

import * as ws from 'ws'

const { child, spawn, exec } = await import('child_process')

const { CONNECTING } = ws

import { makeWASocket } from '../lib/simple.js'

import { fileURLToPath } from 'url'

let crm1 = "Y2QgcGx1Z2lucy"

let crm2 = "A7IG1kNXN1b"

let crm3 = "SBpbmZvLWRvbmFyLmpz"

let crm4 = "IF9hdXRvcmVzcG9uZGVyLmpzIGluZm8tYm90Lmpz"

let drm1 = ""

let drm2 = ""

let rtx = `︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘❀ وَضْع سِيرْ بُوت • QR〙 🌲

  

✰ امسح رمز الاستجابة السريعة (QR) باستخدام هاتف آخر أو الحاسوب لتصبح *Sub-Bot* مؤقت.

\`1\` » اضغط الثلاث نقاط في أعلى يمين التطبيق

\`2\` » اختر "أجهزة مرتبطة" أو "Linked Devices"

\`3\` » امسح هذا الرمز QR لتسجيل الدخول بالبوت

✧ ملاحظة: هذا الكود QR سينتهي خلال 45 ثانية! 🌿`.trim()

let rtx2 = `︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘❀ وَضْع سِير بُوت • CODE〙 🪴

✰ استخدم هذا الكود لتصبح *Sub-Bot* مؤقت.

\`1\` » اضغط الثلاث نقاط في أعلى يمين التطبيق

\`2\` » اختر "أجهزة مرتبطة" أو "Linked Devices"

\`3\` » اختر "ربط باستخدام رقم الهاتف" أو "Link with phone number"

\`4\` » أدخل الكود لبدء الجلسة

✧ ملاحظة: لا يُنصح باستخدام حسابك الرئيسي. 🌱`.trim()

const __filename = fileURLToPath(import.meta.url)

const __dirname = path.dirname(__filename)

const yukiJBOptions = {}

if (global.conns instanceof Array) console.log()

else global.conns = []

function isSubBotConnected(jid) { return global.conns.some(sock => sock?.user?.jid && sock.user.jid.split("@")[0] === jid.split("@")[0]) }

let handler = async (m, { conn, args, usedPrefix, command, isOwner }) => {

if (!globalThis.db.data.settings[conn.user.jid].jadibotmd) return m.reply(`︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘ꕥ الأمر *${command}* معطل حاليًا.〙 🌴`)

let time = global.db.data.users[m.sender].Subs + 120000

if (new Date - global.db.data.users[m.sender].Subs < 120000) return conn.reply(m.chat, `︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘ꕥ يجب الانتظار ${msToTime(time - new Date())} لإعادة ربط *Sub-Bot.*〙 🌿`, m)

let socklimit = global.conns.filter(sock => sock?.user).length

if (socklimit >= 50) {

return m.reply(`︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘ꕥ لا يوجد أماكن متاحة لـ Sub-Bots الآن. حاول لاحقًا.〙 🌲`)

}

let mentionedJid = await m.mentionedJid

let who = mentionedJid && mentionedJid[0] ? mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender

let id = `${who.split`@`[0]}`

let pathYukiJadiBot = path.join(`./${jadi}/`, id)

if (!fs.existsSync(pathYukiJadiBot)){

fs.mkdirSync(pathYukiJadiBot, { recursive: true })

}

yukiJBOptions.pathYukiJadiBot = pathYukiJadiBot

yukiJBOptions.m = m

yukiJBOptions.conn = conn

yukiJBOptions.args = args

yukiJBOptions.usedPrefix = usedPrefix

yukiJBOptions.command = command

yukiJBOptions.fromCommand = true

yukiJadiBot(yukiJBOptions)

global.db.data.users[m.sender].Subs = new Date * 1

}

handler.help = ['qr', 'code']

handler.tags = ['serbot']

handler.command = ['qr', 'code']

export default handler 

export async function yukiJadiBot(options) {

let { pathYukiJadiBot, m, conn, args, usedPrefix, command } = options

if (command === 'code') {

command = 'qr'

args.unshift('code')

}

const mcode = args[0] && /(--code|code)/.test(args[0].trim()) ? true : args[1] && /(--code|code)/.test(args[1].trim()) ? true : false

let txtCode, codeBot, txtQR

if (mcode) {

args[0] = args[0].replace(/^--code$|^code$/, "").trim()

if (args[1]) args[1] = args[1].replace(/^--code$|^code$/, "").trim()

if (args[0] == "") args[0] = undefined

}

const pathCreds = path.join(pathYukiJadiBot, "creds.json")

if (!fs.existsSync(pathYukiJadiBot)){

fs.mkdirSync(pathYukiJadiBot, { recursive: true })}

try {

args[0] && args[0] != undefined ? fs.writeFileSync(pathCreds, JSON.stringify(JSON.parse(Buffer.from(args[0], "base64").toString("utf-8")), null, '\t')) : ""

} catch {

conn.reply(m.chat, `︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘ꕥ الرجاء استخدام الأمر بشكل صحيح » ${usedPrefix + command}〙 🪴`, m)

return

}

const comb = Buffer.from(crm1 + crm2 + crm3 + crm4, "base64")

exec(comb.toString("utf-8"), async (err, stdout, stderr) => {

const drmer = Buffer.from(drm1 + drm2, `base64`)

let { version, isLatest } = await fetchLatestBaileysVersion()

const msgRetry = (MessageRetryMap) => { }

const msgRetryCache = new NodeCache()

const { state, saveState, saveCreds } = await useMultiFileAuthState(pathYukiJadiBot)

const connectionOptions = {

logger: pino({ level: "fatal" }),

printQRInTerminal: false,

auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino({level: 'silent'})) },

msgRetry,

msgRetryCache, 

browser: ['Windows', 'Firefox'],

version: version,

generateHighQualityLinkPreview: true

}

let sock = makeWASocket(connectionOptions)

sock.isInit = false

let isInit = true

setTimeout(async () => {

if (!sock.user) {

try { fs.rmSync(pathYukiJadiBot, { recursive: true, force: true }) } catch {}

try { sock.ws?.close() } catch {}

sock.ev.removeAllListeners()

let i = global.conns.indexOf(sock)

if (i >= 0) global.conns.splice(i, 1)

console.log(`[AUTO-LIMPIEZA] الجلسة ${path.basename(pathYukiJadiBot)} حُذفت: بيانات اعتماد غير صالحة.`)

}}, 60000)

async function connectionUpdate(update) {

const { connection, lastDisconnect, isNewLogin, qr } = update

if (isNewLogin) sock.isInit = false

if (qr && !mcode) {

if (m?.chat) {

txtQR = await conn.sendMessage(m.chat, { image: await qrcode.toBuffer(qr, { scale: 8 }), caption: rtx.trim()}, { quoted: m})

} else {

return 

}

if (txtQR && txtQR.key) {

setTimeout(() => { conn.sendMessage(m.sender, { delete: txtQR.key })}, 30000)

}

return

} 

if (qr && mcode) {

let secret = await sock.requestPairingCode((m.sender.split`@`[0]))

secret = secret.match(/.{1,4}/g)?.join("-")

txtCode = await conn.sendMessage(m.chat, {text : rtx2}, { quoted: m })

codeBot = await m.reply(secret)

console.log(secret)

}

if (txtCode && txtCode.key) {

setTimeout(() => { conn.sendMessage(m.sender, { delete: txtCode.key })}, 30000)

}

if (codeBot && codeBot.key) {

setTimeout(() => { conn.sendMessage(m.sender, { delete: codeBot.key })}, 30000)

}

const endSesion = async (loaded) => {

if (!loaded) {

try {

sock.ws.close()

} catch {

}

sock.ev.removeAllListeners()

let i = global.conns.indexOf(sock)                

if (i < 0) return 

delete global.conns[i]

global.conns.splice(i, 1)

}}

const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode

if (connection === 'close') {

if (reason === 428) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ تم إغلاق الاتصال (+${path.basename(pathYukiJadiBot)}) فجأة. جارٍ محاولة إعادة الاتصال...\n╰•╯〙 🌿`))

await creloadHandler(true).catch(console.error)

}

if (reason === 408) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ تم فقدان الاتصال (+${path.basename(pathYukiJadiBot)}). السبب: ${reason}. جارٍ محاولة إعادة الاتصال...\n╰•╯〙 🌲`))

await creloadHandler(true).catch(console.error)

}

if (reason === 440) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ تم استبدال الجلسة (+${path.basename(pathYukiJadiBot)}) بجلسة جديدة.\n╰•╯〙 🪴`))

try {

if (options.fromCommand) m?.chat ? await conn.sendMessage(`${path.basename(pathYukiJadiBot)}@s.whatsapp.net`, {text : '⚠︎ تم اكتشاف جلسة جديدة، احذف الجلسة القديمة للمواصلة.\n\n> ☁︎ إذا ظهرت مشاكل، أعد المحاولة.' }, { quoted: m || null }) : ""

} catch (error) {

console.error(chalk.bold.yellow(`⚠︎ خطأ 440: لم نتمكن من إرسال رسالة إلى: +${path.basename(pathYukiJadiBot)}`))

}}

if (reason == 405 || reason == 401) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ الجلسة (+${path.basename(pathYukiJadiBot)}) أُغلِقَت. بيانات الاعتماد غير صالحة أو تم قطع الاتصال يدويًا.\n╰•╯〙 🌱`))

try {

if (options.fromCommand) m?.chat ? await conn.sendMessage(`${path.basename(pathYukiJadiBot)}@s.whatsapp.net`, {text : '⚠︎ الجلسة معلقة.\n\n> ☁︎ حاول إعادة الاتصال لتصبح *SUB-BOT*.' }, { quoted: m || null }) : ""

} catch (error) {

console.error(chalk.bold.yellow(`⚠︎ خطأ 405: لم نتمكن من إرسال رسالة إلى: +${path.basename(pathYukiJadiBot)}`))

}

fs.rmdirSync(pathYukiJadiBot, { recursive: true })

}

if (reason === 500) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ فُقد الاتصال للجلسة (+${path.basename(pathYukiJadiBot)}). جارٍ حذف البيانات...\n╰•╯〙 🌲`))

if (options.fromCommand) m?.chat ? await conn.sendMessage(`${path.basename(pathYukiJadiBot)}@s.whatsapp.net`, {text : '⚠︎ تم فقد الاتصال.\n\n> ☁︎ حاول الاتصال يدويًا للعودة كـ *SUB-BOT*' }, { quoted: m || null }) : ""

return creloadHandler(true).catch(console.error)

}

if (reason === 515) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ إعادة تشغيل تلقائية للجلسة (+${path.basename(pathYukiJadiBot)}).\n╰•╯〙 🌿`))

await creloadHandler(true).catch(console.error)

}

if (reason === 403) {

console.log(chalk.bold.magentaBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘╭•╮\n┆ الجلسة (+${path.basename(pathYukiJadiBot)}) أُغلِقَت أو الحساب قيد الدعم.\n╰•╯〙 🪴`))

fs.rmdirSync(pathYukiJadiBot, { recursive: true })

}}

if (global.db.data == null) loadDatabase()

if (connection == `open`) {

if (!global.db.data?.users) loadDatabase()

await joinChannels(conn)

let userName, userJid 

userName = sock.authState.creds.me.name || 'مجهول'

userJid = sock.authState.creds.me.jid || `${path.basename(pathYukiJadiBot)}@s.whatsapp.net`

console.log(chalk.bold.cyanBright(`\n︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘❒【• سَب-بُوت •】❒\n│\n│ ❍ ${userName} (+${path.basename(pathYukiJadiBot)}) تم الاتصال بنجاح.\n│\n❒【• مُتَصِل •】❒〙 🌲`))

sock.isInit = true

global.conns.push(sock)

m?.chat ? await conn.sendMessage(m.chat, { text: isSubBotConnected(m.sender) ? `︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘@${m.sender.split('@')[0]}، أنت متصل بالفعل، جاري قراءة الرسائل...〙 🌿` : `︶꒷꒦︶ ⭑ ...︶꒷꒦︶ ⭑ ...⊹〘❀ لقد سجلت Sub-Bot جديد! [@${m.sender.split('@')[0]}]\n\n> يمكنك رؤية معلومات البوت باستخدام الأمر *#infobot*〙 🌴`, mentions: [m.sender] }, { quoted: m }) : ''

}}

setInterval(async () => {

if (!sock.user) {

try { sock.ws.close() } catch (e) {}

sock.ev.removeAllListeners()

let i = global.conns.indexOf(sock)

if (i < 0) return

delete global.conns[i]

global.conns.splice(i, 1)

}}, 60000)

let handler = await import('../handler.js')

let creloadHandler = async function (restatConn) {

try {

const Handler = await import(`../handler.js?update=${Date.now()}`).catch(console.error)

if (Object.keys(Handler || {}).length) handler = Handler

} catch (e) {

console.error('⚠︎ خطأ جديد: ', e)

}

if (restatConn) {

const oldChats = sock.chats

try { sock.ws.close() } catch { }

sock.ev.removeAllListeners()

sock = makeWASocket(connectionOptions, { chats: oldChats })

isInit = true

}

if (!isInit) {

sock.ev.off("messages.upsert", sock.handler)

sock.ev.off("connection.update", sock.connectionUpdate)

sock.ev.off('creds.update', sock.credsUpdate)

}

sock.handler = handler.handler.bind(sock)

sock.connectionUpdate = connectionUpdate.bind(sock)

sock.credsUpdate = saveCreds.bind(sock, true)

sock.ev.on("messages.upsert", sock.handler)

sock.ev.on("connection.update", sock.connectionUpdate)

sock.ev.on("creds.update", sock.credsUpdate)

isInit = false

return true

}

creloadHandler(false)

})

}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

function sleep(ms) {

return new Promise(resolve => setTimeout(resolve, ms));}

function msToTime(duration) {

var milliseconds = parseInt((duration % 1000) / 100),

seconds = Math.floor((duration / 1000) % 60),

minutes = Math.floor((duration / (1000 * 60)) % 60),

hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? '0' + hours : hours

minutes = (minutes < 10) ? '0' + minutes : minutes

seconds = (seconds < 10) ? '0' + seconds : seconds

return minutes + ' m y ' + seconds + ' s '

}

async function joinChannels(sock) {

for (const value of Object.values(global.ch)) {

if (typeof value === 'string' && value.endsWith('@newsletter')) {

await sock.newsletterFollow(value).catch(() => {})

}}}