import axios from 'axios'

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return conn.reply(m.chat, `> ⓘ \`هات رابط الفيديو او اكتب اي اللي عايز تبحث عنو 🐦\``, m)
  }

  const isUrl = /(?:https:?\/{2})?(?:www\.|vm\.|vt\.|t\.)?tiktok\.com\/([^\s&]+)/gi.test(text)
  try {
    await m.react('🕒')

    if (isUrl) {
      const res = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(text)}?hd=1`)
      const data = res.data?.data
      if (!data?.play && !data?.music) return conn.reply(m.chat, '> ⓘ \`الـرابـط مـش شـغـال ي نـجـم او مـفـيـش محتوي\`', m)

      const { title, duration, author, play, music } = data

      // Si el comando es para audio
      if (command === 'tiktokaudio' || command === 'tta' || command === 'ttaudio') {
        if (!music) {
          return conn.reply(m.chat, '> ⓘ \`حدث خطاء اثناء جلب الصوت من الفيديو 🐦\`', m)
        }

        await conn.sendMessage(
          m.chat,
          {
            audio: { url: music },
            mimetype: 'audio/mpeg',
            fileName: `tiktok_audio.mp3`,
            ptt: false
          },
          { quoted: m }
        )

        await m.react('✅')
        return
      }

      // Comando normal de TikTok (video)
      const caption = `> ⓘ \`العنوان:\` *${title || 'غير معروف'}*\n> ⓘ \`صاحب الفديو:\` *${author?.nickname || 'غير معروف'}*`

      await conn.sendMessage(m.chat, { video: { url: play }, caption }, { quoted: m })

    } else {
      // Búsqueda por texto (solo para comando normal)
      if (command === 'tiktokaudio' || command === 'tta' || command === 'ttaudio') {
        return conn.reply(m.chat, '> ⓘ \`لتنزيل الصوت، تحتاج إلى رابط TikTok\`', m)
      }

      const res = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/feed/search',
        headers: { 
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        data: { keywords: text, count: 5, cursor: 0, HD: 1 }
      })

      const results = res.data?.data?.videos?.filter(v => v.play) || []
      if (results.length === 0) return conn.reply(m.chat, '> ⓘ \`لم يتم العثور على مقاطع فيديو 🐦\`', m)

      // Enviar solo el primer resultado
      const video = results[0]
      const caption = `> ⓘ \`العنوان:\` *${video.title || 'غير متوفر'}*\n> ⓘ \`صاحب الفيديو:\` *${video.author?.nickname || 'غير متوفر'}*`
      
      await conn.sendMessage(m.chat, { video: { url: video.play }, caption }, { quoted: m })
    }

    await m.react('✅')
  } catch (e) {
    await m.react('❌')
    await conn.reply(m.chat, `> ⓘ \`خطاء:\` *${e.message}*`, m)
  }
}

handler.help = ['tiktok', 'tiktokaudio']
handler.tags = ['downloader']
handler.command = ['تيك', 'tt', 'tiktokaudio', 'tta', 'ttaudio']
handler.group = true

export default handler