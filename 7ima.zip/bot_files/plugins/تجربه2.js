import axios from "axios";
import cheerio from "cheerio";

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(`❌ اكتب كلمة للبحث\n\nمثال:\n.حديث الصبر`);
  }

  try {
    await conn.sendMessage(m.chat, {
      react: { text: "📖", key: m.key }
    });

    // البحث في موقع الدرر السنية
    const searchUrl = `https://dorar.net/hadith/search?q=${encodeURIComponent(text)}`;
    
    const { data } = await axios.get(searchUrl, {
      headers: { 
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "text/html"
      },
      timeout: 20000
    });

    const $ = cheerio.load(data);
    
    // استخراج الأحاديث بطريقة جديدة
    let hadiths = [];
    
    // البحث في جميع العناصر
    $('*').each((i, el) => {
      const element = $(el);
      const html = element.html() || '';
      const textContent = element.text().trim();
      
      // البحث عن النمط الصحيح للأحاديث
      if (textContent.length > 100 && textContent.length < 2000) {
        // تحقق من وجود معلومات الحديث المنظمة
        const hasRawi = textContent.includes('الراوي:') || textContent.includes('الراوي :');
        const hasMuhaddith = textContent.includes('المحدث:') || textContent.includes('المحدث :');
        const hasSource = textContent.includes('المصدر:') || textContent.includes('المصدر :') || 
                         textContent.includes('صحيح') || textContent.includes('سنن') || 
                         textContent.includes('مسند') || textContent.includes('موطأ');
        
        // يجب أن يحتوي على حديث ومعلومات
        if (hasRawi && hasMuhaddith && textContent.includes('قال')) {
          hadiths.push(textContent);
        }
      }
    });
    
    // إذا لم نجد بالطريقة الأولى، نبحث في النصوص المنظمة
    if (hadiths.length === 0) {
      // البحث عن النصوص المنظمة مثل الموقع
      const allText = $('body').text();
      const lines = allText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
      
      let currentHadith = [];
      let inHadithBlock = false;
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // بداية كتلة حديث
        if (line.includes('قال') && (line.includes('رسول') || line.includes('النبي')) && line.length < 500) {
          if (currentHadith.length > 0) {
            const hadithText = currentHadith.join('\n');
            if (hadithText.length > 100) {
              hadiths.push(hadithText);
            }
          }
          currentHadith = [line];
          inHadithBlock = true;
        }
        // إذا كنا في كتلة حديث
        else if (inHadithBlock) {
          // إضافة خطوط المعلومات (الراوي، المحدث، إلخ)
          if (line.includes('الراوي:') || line.includes('المحدث:') || 
              line.includes('المصدر:') || line.includes('الدرجة:') ||
              line.includes('صحيح') || line.includes('حسن') || line.includes('ضعيف')) {
            currentHadith.push(line);
          }
          // إذا كان النص طويلاً جداً أو يحتوي على كلمات غير مرغوبة، ننهي الكتلة
          else if (line.length > 200 || line.includes('بحث') || line.includes('نتائج')) {
            inHadithBlock = false;
          }
        }
      }
      
      // إضافة آخر حديث
      if (currentHadith.length > 0) {
        const hadithText = currentHadith.join('\n');
        if (hadithText.length > 100) {
          hadiths.push(hadithText);
        }
      }
    }
    
    // تنظيف وتنسيق الأحاديث
    const formattedHadiths = [];
    
    hadiths.forEach((hadithText, index) => {
      // تنظيف النص
      let cleanText = hadithText
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim();
      
      // استخراج أجزاء الحديث
      const hadithParts = {
        number: index + 1,
        text: '',
        rawi: '',
        muhaddith: '',
        source: '',
        grade: ''
      };
      
      // استخراج نص الحديث (الجزء قبل الراوي)
      const rawiIndex = Math.max(
        cleanText.indexOf('الراوي:'),
        cleanText.indexOf('الراوي :'),
        cleanText.indexOf('المحدث:'),
        cleanText.indexOf('المحدث :')
      );
      
      if (rawiIndex > 0) {
        hadithParts.text = cleanText.substring(0, rawiIndex).trim();
      } else {
        // إذا لم نجد مؤشر، نأخذ أول 300 حرف كنص
        hadithParts.text = cleanText.substring(0, 300).trim();
      }
      
      // استخراج الراوي
      const rawiMatch = cleanText.match(/الراوي[:\s]+([^\\]+?)(?=\s*(المحدث|المصدر|الدرجة|$))/);
      if (rawiMatch) hadithParts.rawi = rawiMatch[1].trim();
      
      // استخراج المحدث
      const muhaddithMatch = cleanText.match(/المحدث[:\s]+([^\\]+?)(?=\s*(المصدر|الدرجة|$))/);
      if (muhaddithMatch) hadithParts.muhaddith = muhaddithMatch[1].trim();
      
      // استخراج المصدر
      const sourceMatch = cleanText.match(/المصدر[:\s]+([^\\]+?)(?=\s*(الدرجة|$))/);
      if (sourceMatch) {
        hadithParts.source = sourceMatch[1].trim();
      } else {
        // البحث عن مصادر معروفة
        const knownSources = ['البخاري', 'مسلم', 'الترمذي', 'النسائي', 'أبو داود', 'ابن ماجه', 'مالك', 'أحمد'];
        for (const source of knownSources) {
          if (cleanText.includes(source)) {
            hadithParts.source = source;
            break;
          }
        }
      }
      
      // استخراج الدرجة
      if (cleanText.includes('صحيح')) hadithParts.grade = 'صحيح';
      else if (cleanText.includes('حسن')) hadithParts.grade = 'حسن';
      else if (cleanText.includes('ضعيف')) hadithParts.grade = 'ضعيف';
      
      // إضافة فقط إذا كان هناك نص حديث
      if (hadithParts.text && hadithParts.text.length > 30) {
        formattedHadiths.push(hadithParts);
      }
    });
    
    // الحد إلى 5 أحاديث
    const finalHadiths = formattedHadiths.slice(0, 5);
    
    if (finalHadiths.length === 0) {
      return m.reply(`❌ لم أجد أحاديث للبحث: "${text}"`);
    }
    
    // بناء الرسالة بالتنسيق المطلوب
    let message = `*⎔ ⋅ ───━ •﹝📖 نتائج البحث عن الأحاديث ﹞• ━─── ⋅ ⎔*\n\n`;
    message += `🔎 *كلمة البحث:* "${text}"\n`;
    message += `📊 *عدد النتائج:* ${finalHadiths.length}\n\n`;
    message += `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n`;
    
    finalHadiths.forEach((hadith, index) => {
      message += `*📜 الحديث ${hadith.number}:*\n`;
      message += `────────────────\n`;
      message += `${hadith.number}  - ${hadith.text}\n\n`;
      
      message += `👤 *الراوي:* \n\t\t\t${hadith.rawi || 'غير معروف'}\n`;
      
      if (hadith.muhaddith) {
        message += `🎓 *المحدث:* \n\t\t\t${hadith.muhaddith}\n`;
      }
      
      message += `✅ *حكم المحدث:* ${hadith.grade || 'غير محدد'} | *المصدر:* \n\n\t\t\t`;
      message += `${hadith.source || 'غير معروف'}\n\n`;
      
      message += `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n\n`;
    });
    
    // إرسال الرسالة
    if (message.length <= 4000) {
      await conn.sendMessage(m.chat, {
        text: message,
        buttons: [
          { buttonId: `.حديث ${text}`, buttonText: { displayText: "🔄 بحث جديد" }, type: 1 }
        ],
        headerType: 1
      });
    } else {
      // تقسيم الرسالة إذا كانت طويلة
      const parts = message.match(/[\s\S]{1,4000}/g) || [];
      
      for (let i = 0; i < parts.length; i++) {
        const partMessage = parts[i];
        const buttons = (i === 0) ? [
          { buttonId: `.حديث ${text}`, buttonText: { displayText: "🔄 بحث جديد" }, type: 1 }
        ] : undefined;
        
        await conn.sendMessage(m.chat, {
          text: partMessage,
          buttons: buttons
        });
        
        if (i < parts.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }

  } catch (error) {
    console.error('خطأ:', error.message);
    m.reply(`⚠️ حدث خطأ في البحث: ${error.message}`);
  }
};

handler.help = ["حديث"];
handler.tags = ["islam"];
handler.command = /^حديث$/i;

export default handler;