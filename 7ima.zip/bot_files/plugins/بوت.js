import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";

const handler = async (m, { conn }) => {
    const imageUrl = "https://files.catbox.moe/n0vw5a.jpg"; // رابط الصورة المصغرة
    const channelLink = "https://whatsapp.com/channel/0029VbB5KQM2ZjCkwJZrOS2e"; // رابط القناة

    // تجهيز الصورة المصغرة
    const media = await prepareWAMessageMedia(
        { image: { url: imageUrl } },
        { upload: conn.waUploadToServer }
    );

    // العلامة fakegif
    let fakegif = {
        key: {
            participant: `0@s.whatsapp.net`,
            remoteJid: "6289643739077-1613049930@g.us",
        },
        message: {
            videoMessage: {
                title: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝❄️✰',
                h: "Hmm",
                seconds: '99999',
                gifPlayback: true,
                caption: '♪ 𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 الـتـوب❄',
                jpegThumbnail: false
            }
        }
    };

    // إنشاء الرسالة التفاعلية مع زر القناة فقط
    const interactiveMessage = {
        body: { text: "مـرحـبا بـك يـا بـطـل فـي عـالـم بـوتات الـواتس♥" },
        footer: { text: "𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝" },
        header: { 
            title: "𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝", 
            hasMediaAttachment: true, 
            imageMessage: media.imageMessage 
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "اشـتـراك ي بـطـل 🍷",
                        url: channelLink
                    })
                }
            ]
        }
    };

    // إرسال العلامة fakegif أولاً
    await conn.relayMessage(m.chat, fakegif.message, { messageId: fakegif.key.id });

    // إرسال الرسالة التفاعلية
    let msg = generateWAMessageFromContent(
        m.chat,
        { viewOnceMessage: { message: { interactiveMessage } } },
        { userJid: conn.user.jid, quoted: m }
    );

    conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.command = /^بوت$/i; // تشغيل الكود عند كتابة ".بوت"

export default handler;