let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
*↷─────〔 🌳 〕─────↶*
*مـࢪحـبـاََ ¦ ${taguser} ¦ 💖*
*قـسـم الـتــحــويــلات*
*↷─────〔  🌳 〕─────↶*

∘₊✧──────🌹──────✧₊∘
> ✘ لــصــوت
> ✘ لــصــوره
> ✘ لــفــيــديــو
> ✘ حــقــوق
> ✘ لــرابــط
> ✘ إخــتـصــار
> ✘ تــحـسـيــن
> ✘ تــعــديــل
> ✘ حــذف_خـلـفـيــه
> ✘ رابــطــي
> ✘ أيــدي
> ✘ تـعـديـل
> ✘ لـمـجـسـم 
∘₊✧──────🌹──────✧₊∘

قَـسٰــــم࣬ يــقَــډم࣬ أدوات شــامــلـة لــلـتـحـويـلات و الــتـصــامـيـم بــطـريـقـة سـريـعـة و مـثـاليـة 💖🎨
`;

  const emojiReaction = '🧗';

  try {
    // إرسال الريأكت
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    // إرسال الصورة مع الكابشن فقط
    await conn.sendMessage(m.chat, {
      image: { url: 'https://files.catbox.moe/3i6ryn.jpg' },
      caption: message,
      mentions: [m.sender]
    });

  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق4)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;