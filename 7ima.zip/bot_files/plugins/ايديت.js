import axios from 'axios';

import baileys from '@whiskeysockets/baileys';

const { proto, generateWAMessageFromContent, generateWAMessageContent } = baileys;

// دالة لإنشاء رسالة فيديو لبايليس

async function createVideoMessage(conn, url) {

  const { videoMessage } = await generateWAMessageContent(

    { video: { url } },

    { upload: conn.waUploadToServer }

  );

  return videoMessage;

}

// دالة لخلط النتائج عشوائيًا

function shuffleArray(array) {

  for (let i = array.length - 1; i > 0; i--) {

    const j = Math.floor(Math.random() * (i + 1));

    [array[i], array[j]] = [array[j], array[i]];

  }

}

let handler = async (m, { conn }) => {

  const chatId = m.chat;

    // 🟢 رسالة انتظار

  await conn.sendMessage(chatId, { text: "⏳ جاري البحث عن الايديت، انتظر قليلاً..." }, { quoted: m });
    
  // ⬅️ أول ما يستقبل الأمر يتفاعل بريأكت

  await conn.sendMessage(m.chat, { react: { text: "🎬", key: m.key } });

  const text = m.text || '';

  const args = text.trim().split(/\s+/).slice(1);

  let query = args.join(' ').trim();

  if (!query) {

    query = 'ايديت';

  } else {

    if (!query.startsWith('ايديت')) {

      query = 'edit ' + query;

    }

  }

  try {

    const { data: response } = await axios.get(

      'https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=' + encodeURIComponent(query)

    );

    let searchResults = response.data || [];

    shuffleArray(searchResults);

    let selectedResults = searchResults.splice(0, 6);

    if (!selectedResults.length) {

      await conn.sendMessage(chatId, {

        text: '🙈 لم أعثر على نتائج مناسبة لبحثك.'

      }, { quoted: m });

      return;

    }

    let cards = [];

    for (let result of selectedResults) {

      cards.push({

        body: proto.Message.InteractiveMessage.Body.fromObject({ text: null }),

        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: '𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝 🍷' }),

        header: proto.Message.InteractiveMessage.Header.fromObject({

          hasMediaAttachment: true,

          videoMessage: await createVideoMessage(conn, result.nowm)

        }),

        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({

          buttons: []

        })

      });

    }

    const responseMessage = generateWAMessageFromContent(

      chatId,

      {

        viewOnceMessage: {

          message: {

            messageContextInfo: {

              deviceListMetadata: {},

              deviceListMetadataVersion: 2

            },

            interactiveMessage: proto.Message.InteractiveMessage.fromObject({

              body: proto.Message.InteractiveMessage.Body.create({

                text: '⚠️ تنبيه: المطوّر غير مسؤول عن الموسيقى أو المحتوى غير اللائق.\n\n[❗️] نتائج البحث عن : ' + query

              }),

              footer: proto.Message.InteractiveMessage.Footer.create({

                text: '`𝙼𝚎𝚕𝚒𝚘𝚍𝚊𝚜 𝚋𝚘𝚝 🍷`'

              }),

              header: proto.Message.InteractiveMessage.Header.create({

                hasMediaAttachment: false

              }),

              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({

                cards

              })

            })

          }

        }

      },

      { quoted: m }

    );

    await conn.relayMessage(chatId, responseMessage.message, {

      messageId: responseMessage.key.id

    });

  } catch (err) {

    console.error('❌ خطأ في البحث عن ايديت:', err);

    await conn.sendMessage(chatId, {

      text: '❌ حصلت مشكلة أثناء البحث عن ايديت. جرب لاحقاً.',

    }, { quoted: m });

  }

};

handler.help = ['ايديت <كلمة البحث>'];

handler.tags = ['search'];

handler.command = /^(ايديت)$/i;

export default handler;