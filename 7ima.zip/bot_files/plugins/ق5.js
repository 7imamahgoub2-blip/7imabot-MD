let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
*↷─────〔 🌳 〕─────↶*
*مـࢪحـبـاََ ¦ ${taguser} ¦ 💖*
*قـسـم الـتـحـمـيـل*
*↷─────〔  🌳 〕─────↶*

∘₊✧──────🌹──────✧₊∘
> ✘ كــروم
> ✘ شــغـل
> ✘ يــوتـيـوب
> ✘ فــيـديـو
> ✘ أيــديـت
> ✘ أســتـوريـهـات
> ✘ تــصــمـيـم
> ✘ خــلـفـيـات
> ✘ أيـديـت-مـخـتـلـط
> ✘ خــلـفـيـه
> ✘ جــيـت
> ✘ مــيـديـا-فــايـر
> ✘ تــيـك
> ✘ تــرجـمـه
> ✘ أيـديـت
> ✘ بـينـرسـت
∘₊✧──────🌹──────✧₊∘

قَـسٰــــم࣬ يــقَــډم࣬ أوامـــر التحميـل و الأدوات للتحميل من جميع المواقع بــسـهولـة و سرعـة 💖⬇️
`;

  const emojiReaction = '⬇️';

  try {
    // إرسال الريأكت
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    // إرسال الصورة مع الكابشن فقط
    await conn.sendMessage(m.chat, {
      image: { url: 'https://files.catbox.moe/3i6ryn.jpg' },
      caption: message,
      mentions: [m.sender]
    });

  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق5)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;